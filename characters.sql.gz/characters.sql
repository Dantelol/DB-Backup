-- MySQL dump 10.16  Distrib 10.1.21-MariaDB, for Win32 (AMD64)
--
-- Host: localhost    Database: localhost
-- ------------------------------------------------------
-- Server version	5.7.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `characters`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `characters` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `characters`;

--
-- Table structure for table `arena_team`
--

DROP TABLE IF EXISTS `arena_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arena_team` (
  `arenateamid` int(10) unsigned NOT NULL DEFAULT '0',
  `name` char(255) NOT NULL,
  `captainguid` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `BackgroundColor` int(10) unsigned NOT NULL DEFAULT '0',
  `EmblemStyle` int(10) unsigned NOT NULL DEFAULT '0',
  `EmblemColor` int(10) unsigned NOT NULL DEFAULT '0',
  `BorderStyle` int(10) unsigned NOT NULL DEFAULT '0',
  `BorderColor` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`arenateamid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arena_team`
--

LOCK TABLES `arena_team` WRITE;
/*!40000 ALTER TABLE `arena_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `arena_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `arena_team_member`
--

DROP TABLE IF EXISTS `arena_team_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arena_team_member` (
  `arenateamid` int(10) unsigned NOT NULL DEFAULT '0',
  `guid` int(10) unsigned NOT NULL DEFAULT '0',
  `played_week` int(10) unsigned NOT NULL DEFAULT '0',
  `wons_week` int(10) unsigned NOT NULL DEFAULT '0',
  `played_season` int(10) unsigned NOT NULL DEFAULT '0',
  `wons_season` int(10) unsigned NOT NULL DEFAULT '0',
  `personal_rating` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`arenateamid`,`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arena_team_member`
--

LOCK TABLES `arena_team_member` WRITE;
/*!40000 ALTER TABLE `arena_team_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `arena_team_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `arena_team_stats`
--

DROP TABLE IF EXISTS `arena_team_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arena_team_stats` (
  `arenateamid` int(10) unsigned NOT NULL DEFAULT '0',
  `rating` int(10) unsigned NOT NULL DEFAULT '0',
  `games_week` int(10) unsigned NOT NULL DEFAULT '0',
  `wins_week` int(10) unsigned NOT NULL DEFAULT '0',
  `games_season` int(10) unsigned NOT NULL DEFAULT '0',
  `wins_season` int(10) unsigned NOT NULL DEFAULT '0',
  `rank` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`arenateamid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arena_team_stats`
--

LOCK TABLES `arena_team_stats` WRITE;
/*!40000 ALTER TABLE `arena_team_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `arena_team_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auction`
--

DROP TABLE IF EXISTS `auction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auction` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `houseid` int(11) unsigned NOT NULL DEFAULT '0',
  `itemguid` int(11) unsigned NOT NULL DEFAULT '0',
  `item_template` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Item Identifier',
  `item_count` int(11) unsigned NOT NULL DEFAULT '0',
  `item_randompropertyid` int(11) NOT NULL DEFAULT '0',
  `itemowner` int(11) unsigned NOT NULL DEFAULT '0',
  `buyoutprice` int(11) NOT NULL DEFAULT '0',
  `time` bigint(40) unsigned NOT NULL DEFAULT '0',
  `buyguid` int(11) unsigned NOT NULL DEFAULT '0',
  `lastbid` int(11) NOT NULL DEFAULT '0',
  `startbid` int(11) NOT NULL DEFAULT '0',
  `deposit` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auction`
--

LOCK TABLES `auction` WRITE;
/*!40000 ALTER TABLE `auction` DISABLE KEYS */;
/*!40000 ALTER TABLE `auction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bugreport`
--

DROP TABLE IF EXISTS `bugreport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bugreport` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Identifier',
  `type` longtext NOT NULL,
  `content` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Debug System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bugreport`
--

LOCK TABLES `bugreport` WRITE;
/*!40000 ALTER TABLE `bugreport` DISABLE KEYS */;
/*!40000 ALTER TABLE `bugreport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_action`
--

DROP TABLE IF EXISTS `character_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_action` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `button` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `action` int(11) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`button`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_action`
--

LOCK TABLES `character_action` WRITE;
/*!40000 ALTER TABLE `character_action` DISABLE KEYS */;
INSERT INTO `character_action` VALUES (1,0,1,64),(1,1,8401,0),(1,2,8406,0),(1,10,159,128),(1,11,2070,128),(3,1,1752,0),(3,3,2098,0),(3,8,2764,0),(3,11,2070,128),(3,54,1,64),(3,55,3,64),(3,56,2,64),(3,57,4,64),(3,58,6,64),(6,0,6603,0),(6,1,14260,0),(6,2,75,0),(6,3,13549,0),(6,4,28734,0),(6,5,28730,0),(6,6,1130,0),(6,10,159,128),(6,11,4540,128),(7,1,1757,0),(7,3,2098,0),(7,7,1776,0),(7,8,2764,0),(7,11,2070,128),(7,17,3273,0),(7,50,1251,128),(7,51,2656,0),(7,54,6603,0),(7,67,1784,0),(7,71,118,128),(7,79,921,0),(8,17,3273,0),(8,50,1251,128),(8,54,6603,0),(8,55,71,0),(8,56,2457,0),(8,66,2687,0),(8,67,6673,0),(8,71,118,128),(8,72,100,0),(8,75,284,0),(8,79,6546,0),(8,80,1715,0),(8,81,6343,0),(8,83,117,128),(8,86,284,0),(8,87,7386,0),(8,91,6343,0),(8,92,355,0),(9,72,6603,0),(9,73,78,0),(9,74,20580,0),(9,83,117,128),(10,0,6603,0),(10,1,2973,0),(10,2,75,0),(10,10,159,128),(10,11,117,128),(11,72,11578,0),(11,73,29707,0),(11,74,30330,0),(11,75,25264,0),(11,76,25208,0),(11,77,11585,0),(11,78,25212,0),(11,79,12323,0),(11,80,25236,0),(11,81,6554,0),(11,82,1719,0),(11,83,117,128),(15,0,6603,0),(15,1,695,0),(15,2,687,0),(15,10,159,128),(15,11,4604,128),(16,0,6603,0),(16,1,705,0),(16,2,707,0),(16,3,172,0),(16,5,5782,0),(16,7,696,0),(16,9,1108,0),(16,10,159,128),(16,11,4604,128),(16,28,858,128),(16,31,4541,128),(16,39,2455,128),(16,40,118,128),(16,41,5512,128),(16,43,1179,128),(16,60,1454,0),(16,61,980,0),(16,62,1120,0),(16,63,5512,128),(16,64,6201,0),(16,66,755,0),(16,69,688,0),(16,70,697,0),(16,71,5019,0),(17,72,6603,0),(17,73,78,0),(17,83,4604,128),(18,3,20271,0),(18,5,21084,0),(18,10,159,128),(18,11,20857,128),(18,32,28734,0),(18,33,28730,0),(18,51,19740,0),(18,54,6603,0),(18,66,635,0);
/*!40000 ALTER TABLE `character_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_aura`
--

DROP TABLE IF EXISTS `character_aura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_aura` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `caster_guid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Full Global Unique Identifier',
  `item_guid` int(11) unsigned NOT NULL DEFAULT '0',
  `spell` int(11) unsigned NOT NULL DEFAULT '0',
  `stackcount` int(11) unsigned NOT NULL DEFAULT '1',
  `remaincharges` int(11) unsigned NOT NULL DEFAULT '0',
  `basepoints0` int(11) NOT NULL DEFAULT '0',
  `basepoints1` int(11) NOT NULL DEFAULT '0',
  `basepoints2` int(11) NOT NULL DEFAULT '0',
  `periodictime0` int(11) unsigned NOT NULL DEFAULT '0',
  `periodictime1` int(11) unsigned NOT NULL DEFAULT '0',
  `periodictime2` int(11) unsigned NOT NULL DEFAULT '0',
  `maxduration` int(11) NOT NULL DEFAULT '0',
  `remaintime` int(11) NOT NULL DEFAULT '0',
  `effIndexMask` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`caster_guid`,`item_guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_aura`
--

LOCK TABLES `character_aura` WRITE;
/*!40000 ALTER TABLE `character_aura` DISABLE KEYS */;
INSERT INTO `character_aura` VALUES (3,3,0,37800,1,0,0,0,0,0,0,0,-1,-1,1),(7,7,0,2580,1,0,0,0,0,0,0,0,-1,-1,1),(7,7,560,8091,1,0,60,0,0,0,0,0,1800000,440561,1),(8,8,0,2457,1,0,0,0,0,0,0,0,-1,-1,1),(8,8,1140,2367,1,0,4,0,0,0,0,0,3600000,2509862,1),(11,11,0,2457,1,0,0,0,0,0,0,0,-1,-1,1),(11,11,521,23222,1,0,0,100,0,0,0,0,-1,-1,3),(16,16,0,696,1,0,120,5,0,0,0,0,1800000,1470015,3),(16,16,1167,8112,1,0,3,0,0,0,0,0,1800000,534784,1),(17,17,0,2457,1,0,0,0,0,0,0,0,-1,-1,1),(18,18,0,465,1,0,55,0,0,0,0,0,-1,-1,1),(18,18,0,19740,1,0,20,20,0,0,0,0,600000,161804,3),(18,17379391218647095054,0,24829,1,0,5,5,0,0,0,0,1800000,613753,3);
/*!40000 ALTER TABLE `character_aura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_battleground_data`
--

DROP TABLE IF EXISTS `character_battleground_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_battleground_data` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `instance_id` int(11) unsigned NOT NULL DEFAULT '0',
  `team` int(11) unsigned NOT NULL DEFAULT '0',
  `join_x` float NOT NULL DEFAULT '0',
  `join_y` float NOT NULL DEFAULT '0',
  `join_z` float NOT NULL DEFAULT '0',
  `join_o` float NOT NULL DEFAULT '0',
  `join_map` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_battleground_data`
--

LOCK TABLES `character_battleground_data` WRITE;
/*!40000 ALTER TABLE `character_battleground_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_battleground_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_db_version`
--

DROP TABLE IF EXISTS `character_db_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_db_version` (
  `required_s2345_01_characters_instance` bit(1) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Last applied sql update to DB';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_db_version`
--

LOCK TABLES `character_db_version` WRITE;
/*!40000 ALTER TABLE `character_db_version` DISABLE KEYS */;
INSERT INTO `character_db_version` VALUES (NULL);
/*!40000 ALTER TABLE `character_db_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_declinedname`
--

DROP TABLE IF EXISTS `character_declinedname`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_declinedname` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `genitive` varchar(15) NOT NULL DEFAULT '',
  `dative` varchar(15) NOT NULL DEFAULT '',
  `accusative` varchar(15) NOT NULL DEFAULT '',
  `instrumental` varchar(15) NOT NULL DEFAULT '',
  `prepositional` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_declinedname`
--

LOCK TABLES `character_declinedname` WRITE;
/*!40000 ALTER TABLE `character_declinedname` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_declinedname` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_gifts`
--

DROP TABLE IF EXISTS `character_gifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_gifts` (
  `guid` int(20) unsigned NOT NULL DEFAULT '0',
  `item_guid` int(11) unsigned NOT NULL DEFAULT '0',
  `entry` int(20) unsigned NOT NULL DEFAULT '0',
  `flags` int(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`item_guid`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_gifts`
--

LOCK TABLES `character_gifts` WRITE;
/*!40000 ALTER TABLE `character_gifts` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_gifts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_homebind`
--

DROP TABLE IF EXISTS `character_homebind`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_homebind` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `map` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Map Identifier',
  `zone` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Zone Identifier',
  `position_x` float NOT NULL DEFAULT '0',
  `position_y` float NOT NULL DEFAULT '0',
  `position_z` float NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_homebind`
--

LOCK TABLES `character_homebind` WRITE;
/*!40000 ALTER TABLE `character_homebind` DISABLE KEYS */;
INSERT INTO `character_homebind` VALUES (1,0,12,-8949.95,-132.493,83.5312),(3,0,12,-8949.95,-132.493,83.5312),(6,530,3665,9474.74,-6857.73,17.42),(7,0,87,-9461.63,16.4342,56.9748),(8,0,87,-9463.61,16.0907,56.9626),(10,1,14,-618.518,-4251.67,38.718),(11,0,1,-6240.32,331.033,382.758),(15,0,1,-6240,331,383),(16,0,2102,-5600.86,-529.08,399.654),(17,0,85,1676.71,1678.31,121.67),(18,530,3431,10349.6,-6357.29,33.4026);
/*!40000 ALTER TABLE `character_homebind` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_instance`
--

DROP TABLE IF EXISTS `character_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_instance` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0',
  `instance` int(11) unsigned NOT NULL DEFAULT '0',
  `permanent` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_instance`
--

LOCK TABLES `character_instance` WRITE;
/*!40000 ALTER TABLE `character_instance` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_inventory`
--

DROP TABLE IF EXISTS `character_inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_inventory` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `bag` int(11) unsigned NOT NULL DEFAULT '0',
  `slot` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Item Global Unique Identifier',
  `item_template` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Item Identifier',
  PRIMARY KEY (`item`),
  KEY `idx_guid` (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_inventory`
--

LOCK TABLES `character_inventory` WRITE;
/*!40000 ALTER TABLE `character_inventory` DISABLE KEYS */;
INSERT INTO `character_inventory` VALUES (1,0,31,2,56),(1,0,32,4,1395),(1,0,7,6,55),(1,0,15,8,35),(1,0,3,10,6096),(1,0,23,12,2070),(1,0,24,14,159),(1,0,25,16,6948),(3,0,3,33,49),(3,0,7,35,47),(3,0,6,37,48),(3,0,17,39,28979),(3,0,15,41,2092),(3,0,23,43,2070),(3,0,24,45,6948),(3,0,25,63,750),(3,0,19,66,828),(6,178,5,90,20901),(6,178,2,92,20899),(6,178,1,94,20900),(6,0,23,96,159),(6,0,28,98,20982),(6,0,24,100,6948),(6,0,19,102,2101),(3,0,20,112,17966),(6,0,20,136,20474),(6,0,21,172,5571),(6,0,22,178,805),(7,0,3,182,49),(7,0,7,184,47),(7,0,6,186,48),(7,0,17,188,28979),(7,0,23,192,2070),(7,0,26,194,6948),(6,178,4,204,20993),(6,0,32,205,21000),(6,102,1,207,2512),(6,102,2,208,2512),(6,102,3,209,2512),(6,102,4,210,2512),(6,102,5,211,2512),(6,178,3,212,20996),(7,0,8,281,6070),(6,0,17,282,20838),(6,0,27,287,20813),(7,0,15,303,2057),(7,0,4,380,60),(7,0,14,382,11475),(6,0,25,386,4540),(7,0,24,411,4656),(6,178,0,413,27552),(6,102,0,415,2512),(6,0,26,416,2512),(7,0,25,419,2901),(8,0,3,421,38),(8,0,16,429,2362),(8,1181,0,433,6948),(9,0,15,435,25),(9,0,3,437,6120),(9,0,6,439,6121),(9,0,7,441,6122),(9,0,16,443,2362),(9,0,23,445,117),(9,0,24,447,6948),(6,0,15,448,6256),(6,0,30,450,6529),(6,0,29,451,769),(6,0,31,452,3171),(1,0,86,453,24490),(1,0,5,454,30673),(1,0,28,455,28530),(10,0,3,457,127),(10,0,6,459,6126),(10,0,7,461,6127),(10,0,23,463,159),(10,0,15,465,37),(10,0,24,467,6948),(10,0,19,469,2101),(10,0,17,471,2504),(10,0,25,473,117),(10,469,0,475,2512),(11,0,3,477,38),(11,0,31,479,39),(11,0,25,481,40),(11,0,35,483,25),(11,0,23,485,2362),(11,0,28,489,6948),(10,0,26,490,15917),(11,0,2,492,30979),(11,0,7,493,34569),(11,0,8,494,34441),(11,0,9,496,30969),(11,0,0,497,30972),(11,0,4,498,30975),(11,0,5,499,34546),(11,0,6,500,30977),(11,0,15,501,30902),(11,0,24,502,2771),(11,0,26,503,2589),(11,0,27,504,2592),(11,0,29,505,858),(11,0,30,506,2775),(11,0,32,521,18774),(7,0,28,523,769),(7,0,30,530,2770),(7,0,27,532,2835),(7,0,33,572,118),(7,0,29,579,957),(7,0,31,580,1251),(7,0,32,581,2672),(15,0,4,641,57),(15,0,3,643,6097),(15,0,6,645,1396),(15,0,7,647,59),(15,0,15,649,2092),(15,0,23,651,159),(15,0,24,653,4604),(15,0,25,655,6948),(15,0,26,656,2187),(15,0,27,657,750),(15,0,28,658,4865),(15,0,29,661,7073),(15,0,30,662,7074),(16,0,3,666,6097),(16,0,7,670,59),(16,0,25,678,6948),(16,0,19,708,5571),(17,0,3,802,6125),(17,0,6,804,139),(17,0,7,806,140),(17,0,15,808,25),(17,0,16,810,2362),(17,0,23,812,4604),(17,0,24,814,6948),(16,0,26,825,2894),(8,0,8,851,6070),(16,0,14,862,3153),(8,0,6,876,2962),(16,0,8,890,2326),(8,0,15,897,1161),(16,0,6,909,2958),(8,0,5,918,2690),(16,0,9,920,10550),(16,0,30,922,4541),(16,0,31,926,1179),(16,0,4,930,3216),(8,0,19,937,5572),(8,0,4,943,60),(8,0,7,944,2691),(8,0,24,951,7005),(8,0,9,1008,2653),(16,0,16,1036,15925),(16,0,24,1103,769),(8,937,1,1109,1434),(8,1181,1,1111,1251),(16,0,23,1119,3151),(8,937,0,1136,1191),(16,0,15,1137,2218),(8,1181,2,1138,118),(8,1181,3,1140,2454),(16,0,38,1143,2589),(8,0,25,1145,2806),(10,0,27,1146,2589),(16,708,1,1155,858),(16,708,2,1156,1705),(16,0,27,1163,414),(16,0,29,1170,1503),(8,1181,5,1172,1251),(16,0,28,1174,2287),(16,0,32,1175,1511),(16,0,33,1177,818),(10,0,28,1179,2268),(10,0,29,1180,1501),(8,0,22,1181,4496),(8,0,21,1182,4496),(8,0,20,1183,4496),(16,0,35,1189,2589),(16,0,20,1192,5573),(16,0,37,1194,9811),(16,708,0,1195,2318),(16,708,3,1196,6555),(16,0,36,1200,5512),(18,0,3,1204,24143),(18,0,6,1206,24145),(18,0,23,1212,20857),(18,0,24,1214,159),(18,0,25,1216,6948),(16,708,5,1220,6265),(16,1192,0,1221,9758),(16,1192,1,1222,6265),(18,0,7,1236,20997),(18,0,19,1237,20474),(16,0,34,1239,16310),(18,0,4,1289,20994),(18,0,14,1290,20991),(18,0,9,1291,20999),(18,0,20,1353,5572),(18,0,15,1378,20835),(18,0,26,1380,20847),(18,0,27,1381,20848),(18,0,28,1387,20483),(18,0,29,1390,20847),(18,0,30,1395,20848),(18,0,5,1400,21015),(18,0,31,1403,20799),(18,0,32,1404,20813);
/*!40000 ALTER TABLE `character_inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_pet`
--

DROP TABLE IF EXISTS `character_pet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_pet` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `entry` int(11) unsigned NOT NULL DEFAULT '0',
  `owner` int(11) unsigned NOT NULL DEFAULT '0',
  `modelid` int(11) unsigned DEFAULT '0',
  `CreatedBySpell` int(11) unsigned NOT NULL DEFAULT '0',
  `PetType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `level` int(11) unsigned NOT NULL DEFAULT '1',
  `exp` int(11) unsigned NOT NULL DEFAULT '0',
  `Reactstate` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `loyaltypoints` int(11) NOT NULL DEFAULT '0',
  `loyalty` int(11) unsigned NOT NULL DEFAULT '0',
  `trainpoint` int(11) NOT NULL DEFAULT '0',
  `name` varchar(100) DEFAULT 'Pet',
  `renamed` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `slot` int(11) unsigned NOT NULL DEFAULT '0',
  `curhealth` int(11) unsigned NOT NULL DEFAULT '1',
  `curmana` int(11) unsigned NOT NULL DEFAULT '0',
  `curhappiness` int(11) unsigned NOT NULL DEFAULT '0',
  `savetime` bigint(20) unsigned NOT NULL DEFAULT '0',
  `resettalents_cost` int(11) unsigned NOT NULL DEFAULT '0',
  `resettalents_time` bigint(20) unsigned NOT NULL DEFAULT '0',
  `abdata` longtext,
  `teachspelldata` longtext,
  PRIMARY KEY (`id`),
  KEY `owner` (`owner`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Pet System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_pet`
--

LOCK TABLES `character_pet` WRITE;
/*!40000 ALTER TABLE `character_pet` DISABLE KEYS */;
INSERT INTO `character_pet` VALUES (8,416,16,4449,688,0,11,0,1,0,0,-1,'Rupkin',1,100,191,38,0,1490243234,0,0,'7 2 7 1 7 0 193 7799 129 0 193 6307 129 0 6 2 6 1 6 0 ','0 0 0 0 0 0 0 0 '),(14,1860,16,1132,697,0,14,0,1,0,0,0,'Zangkrast',1,0,368,227,0,1490249596,0,0,'7 2 7 1 7 0 193 3716 129 0 129 0 129 0 6 2 6 1 6 0 ','0 0 0 0 0 0 0 0 ');
/*!40000 ALTER TABLE `character_pet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_pet_declinedname`
--

DROP TABLE IF EXISTS `character_pet_declinedname`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_pet_declinedname` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `owner` int(11) unsigned NOT NULL DEFAULT '0',
  `genitive` varchar(12) NOT NULL DEFAULT '',
  `dative` varchar(12) NOT NULL DEFAULT '',
  `accusative` varchar(12) NOT NULL DEFAULT '',
  `instrumental` varchar(12) NOT NULL DEFAULT '',
  `prepositional` varchar(12) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `owner_key` (`owner`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_pet_declinedname`
--

LOCK TABLES `character_pet_declinedname` WRITE;
/*!40000 ALTER TABLE `character_pet_declinedname` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_pet_declinedname` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_queststatus`
--

DROP TABLE IF EXISTS `character_queststatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_queststatus` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  `status` int(11) unsigned NOT NULL DEFAULT '0',
  `rewarded` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `explored` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `timer` bigint(20) unsigned NOT NULL DEFAULT '0',
  `mobcount1` int(11) unsigned NOT NULL DEFAULT '0',
  `mobcount2` int(11) unsigned NOT NULL DEFAULT '0',
  `mobcount3` int(11) unsigned NOT NULL DEFAULT '0',
  `mobcount4` int(11) unsigned NOT NULL DEFAULT '0',
  `itemcount1` int(11) unsigned NOT NULL DEFAULT '0',
  `itemcount2` int(11) unsigned NOT NULL DEFAULT '0',
  `itemcount3` int(11) unsigned NOT NULL DEFAULT '0',
  `itemcount4` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`quest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_queststatus`
--

LOCK TABLES `character_queststatus` WRITE;
/*!40000 ALTER TABLE `character_queststatus` DISABLE KEYS */;
INSERT INTO `character_queststatus` VALUES (3,7,0,0,0,1490181815,1,0,0,0,0,0,0,0),(3,33,0,0,0,1490181815,0,0,0,0,6,0,0,0),(3,783,1,1,0,1490168713,0,0,0,0,0,0,0,0),(3,5261,1,1,0,1490168713,0,0,0,0,0,0,0,0),(6,834,3,0,0,1490198488,0,0,0,0,0,0,0,0),(6,8325,1,1,0,1490172426,8,0,0,0,0,0,0,0),(6,8326,1,1,0,1490173326,0,0,0,0,0,0,0,0),(6,8327,1,1,0,1490173326,0,0,0,0,0,0,0,0),(6,8330,1,1,0,1490173326,0,0,0,0,0,0,0,0),(6,8334,1,1,0,1490174163,7,7,0,0,0,0,0,0),(6,8335,1,1,0,1490175063,8,2,0,0,0,0,0,0),(6,8336,1,1,0,1490173326,0,0,0,0,0,0,0,0),(6,8338,1,1,0,1490175063,0,0,0,0,0,0,0,0),(6,8345,1,1,0,1490173326,1,0,0,0,0,0,0,0),(6,8346,1,1,0,1490173326,6,0,0,0,0,0,0,0),(6,8347,1,1,0,1490175063,0,0,0,0,0,0,0,0),(6,8350,1,1,0,1490175063,0,0,0,0,0,0,0,0),(6,8463,1,1,0,1490177181,0,0,0,0,0,0,0,0),(6,8468,1,1,0,1490177181,0,0,0,0,0,0,0,0),(6,8472,1,1,0,1490177181,0,0,0,0,0,0,0,0),(6,8895,1,1,0,1490198488,0,0,0,0,0,0,0,0),(6,9035,1,0,0,1490198488,0,0,0,0,0,0,0,0),(6,9119,1,0,0,1490198488,0,0,0,0,0,0,0,0),(6,9352,3,0,0,1490177181,0,0,0,0,0,0,0,0),(6,9393,1,1,0,1490172426,0,0,0,0,0,0,0,0),(6,9484,1,1,1,1490202412,0,0,0,0,0,0,0,0),(6,9485,1,1,1,1490202810,0,0,0,0,0,0,0,0),(6,9486,1,1,1,1490202412,0,0,0,0,0,0,0,0),(6,9673,1,0,0,1490202810,0,0,0,0,0,0,0,0),(6,9704,1,1,0,1490175063,0,0,0,0,0,0,0,0),(6,9705,1,1,0,1490175063,0,0,0,0,0,0,0,0),(6,10072,1,1,0,1490172426,0,0,0,0,0,0,0,0),(7,6,1,1,0,1490176397,0,0,0,0,0,0,0,0),(7,7,1,1,0,1490174597,10,0,0,0,0,0,0,0),(7,15,1,1,0,1490175497,10,0,0,0,0,0,0,0),(7,18,1,1,0,1490175497,0,0,0,0,0,0,0,0),(7,21,1,1,0,1490177297,12,0,0,0,0,0,0,0),(7,33,1,1,0,1490174597,0,0,0,0,0,0,0,0),(7,35,1,0,0,1490225486,0,0,0,0,0,0,0,0),(7,40,1,1,0,1490225486,0,0,0,0,0,0,0,0),(7,47,1,1,0,1490224416,0,0,0,0,0,0,0,0),(7,54,1,1,0,1490177297,0,0,0,0,0,0,0,0),(7,60,1,1,0,1490224416,0,0,0,0,0,0,0,0),(7,61,1,0,0,1490224416,0,0,0,0,1,0,0,0),(7,62,1,1,1,1490224416,0,0,0,0,0,0,0,0),(7,76,3,0,0,1490224416,0,0,0,0,0,0,0,0),(7,239,1,0,0,1490177297,0,0,0,0,0,0,0,0),(7,332,1,1,0,1490177297,0,0,0,0,0,0,0,0),(7,783,1,1,0,1490173697,0,0,0,0,0,0,0,0),(7,2158,1,1,0,1490177297,0,0,0,0,0,0,0,0),(7,3102,1,1,0,1490174597,0,0,0,0,0,0,0,0),(7,3903,1,1,0,1490174597,0,0,0,0,0,0,0,0),(7,3904,1,1,0,1490176397,0,0,0,0,0,0,0,0),(7,3905,1,1,0,1490176397,0,0,0,0,0,0,0,0),(7,5261,1,1,0,1490174597,0,0,0,0,0,0,0,0),(8,6,1,1,0,1490244574,0,0,0,0,0,0,0,0),(8,7,1,1,0,1490242549,10,0,0,0,0,0,0,0),(8,15,1,1,0,1490243449,10,0,0,0,0,0,0,0),(8,18,1,1,0,1490243449,0,0,0,0,0,0,0,0),(8,21,1,1,0,1490244574,12,0,0,0,0,0,0,0),(8,33,1,1,0,1490242549,0,0,0,0,0,0,0,0),(8,35,1,0,0,1490245474,0,0,0,0,0,0,0,0),(8,40,1,1,0,1490245474,0,0,0,0,0,0,0,0),(8,47,1,1,0,1490248174,0,0,0,0,0,0,0,0),(8,60,1,1,0,1490247274,0,0,0,0,0,0,0,0),(8,61,1,1,0,1490248174,0,0,0,0,0,0,0,0),(8,62,1,1,1,1490247274,0,0,0,0,0,0,0,0),(8,76,3,0,0,1490247274,0,0,0,0,0,0,0,0),(8,84,1,1,0,1490247274,0,0,0,0,0,0,0,0),(8,85,1,1,0,1490246374,0,0,0,0,0,0,0,0),(8,86,1,1,0,1490246374,0,0,0,0,4,0,0,0),(8,87,1,1,0,1490247274,0,0,0,0,0,0,0,0),(8,88,3,0,0,1490246374,0,0,0,0,0,0,0,0),(8,106,1,1,0,1490246374,0,0,0,0,0,0,0,0),(8,107,1,1,0,1490247274,0,0,0,0,0,0,0,0),(8,111,1,1,0,1490247274,0,0,0,0,0,0,0,0),(8,112,3,0,0,1490247274,0,0,0,0,0,0,0,0),(8,239,1,0,0,1490245474,0,0,0,0,0,0,0,0),(8,353,1,0,0,1490248174,0,0,0,0,1,0,0,0),(8,783,1,1,0,1490240749,0,0,0,0,0,0,0,0),(8,1097,1,1,0,1490248174,0,0,0,0,0,0,0,0),(8,1638,1,1,0,1490248174,0,0,0,0,0,0,0,0),(8,1639,1,1,0,1490248174,0,0,0,0,0,0,0,0),(8,1640,1,1,1,1490248174,0,0,0,0,0,0,0,0),(8,1665,1,1,0,1490248174,0,0,0,0,0,0,0,0),(8,1666,1,0,0,1490248174,0,0,0,0,0,0,0,0),(8,2158,1,1,0,1490245474,0,0,0,0,0,0,0,0),(8,3100,1,1,0,1490242549,0,0,0,0,0,0,0,0),(8,3903,1,1,0,1490242549,0,0,0,0,0,0,0,0),(8,3904,1,1,0,1490243449,0,0,0,0,0,0,0,0),(8,3905,1,1,0,1490243449,0,0,0,0,0,0,0,0),(8,5261,1,1,0,1490240749,0,0,0,0,0,0,0,0),(10,6062,3,0,0,1490209938,0,0,0,0,1,0,0,0),(11,179,0,0,0,1490210396,0,0,0,0,0,0,0,0),(11,233,0,0,0,1490210396,0,0,0,0,0,0,0,0),(11,1718,1,0,0,1490210396,0,0,0,0,0,0,0,0),(15,179,3,0,0,1490227206,0,0,0,0,2,0,0,0),(15,233,1,0,0,1490227206,0,0,0,0,1,0,0,0),(15,1599,3,0,0,1490227206,0,0,0,0,0,0,0,0),(15,3361,3,0,0,1490227206,0,0,0,0,0,0,0,0),(16,170,1,1,0,1490230106,6,6,0,0,0,0,0,0),(16,179,1,1,0,1490229206,0,0,0,0,0,0,0,0),(16,182,1,1,0,1490230106,14,0,0,0,0,0,0,0),(16,183,1,1,0,1490231286,12,0,0,0,0,0,0,0),(16,218,1,1,0,1490231286,0,0,0,0,0,0,0,0),(16,224,1,1,0,1490248489,10,10,0,0,0,0,0,0),(16,233,1,1,0,1490230106,0,0,0,0,0,0,0,0),(16,234,1,1,0,1490231286,0,0,0,0,0,0,0,0),(16,237,1,1,0,1490249389,10,10,0,0,0,0,0,0),(16,256,3,0,0,1490249596,0,0,0,0,0,0,0,0),(16,263,3,0,0,1490249389,0,0,0,0,0,0,0,0),(16,267,1,1,0,1490248489,0,0,0,0,0,0,0,0),(16,282,1,1,0,1490231286,0,0,0,0,0,0,0,0),(16,287,1,1,1,1490243818,5,0,0,0,0,0,0,0),(16,291,1,1,0,1490244888,0,0,0,0,0,0,0,0),(16,308,0,1,0,1490237960,0,0,0,0,0,0,0,0),(16,310,1,1,0,1490237960,0,0,0,0,0,0,0,0),(16,311,1,1,0,1490243347,0,0,0,0,0,0,0,0),(16,312,1,1,0,1490243818,0,0,0,0,0,0,0,0),(16,313,1,1,0,1490234914,0,0,0,0,0,0,0,0),(16,315,1,1,0,1490243347,0,0,0,0,0,0,0,0),(16,317,1,1,0,1490234914,0,0,0,0,0,0,0,0),(16,318,1,1,0,1490234914,0,0,0,0,0,0,0,0),(16,319,1,1,0,1490243347,6,8,8,0,0,0,0,0),(16,320,1,1,0,1490243818,0,0,0,0,0,0,0,0),(16,399,3,0,0,1490244888,0,0,0,0,0,0,0,0),(16,400,1,1,0,1490232776,0,0,0,0,0,0,0,0),(16,403,1,1,0,1490237960,0,0,0,0,0,0,0,0),(16,412,1,1,0,1490243347,0,0,0,0,0,0,0,0),(16,413,1,1,0,1490247589,0,0,0,0,0,0,0,0),(16,414,1,1,0,1490249596,0,0,0,0,0,0,0,0),(16,415,1,1,0,1490234914,0,0,0,0,0,0,0,0),(16,416,3,0,0,1490249596,0,0,0,0,0,0,0,0),(16,417,1,1,0,1490247589,0,0,0,0,0,0,0,0),(16,418,3,0,0,1490249596,0,0,0,0,0,0,0,0),(16,419,1,1,0,1490247589,0,0,0,0,0,0,0,0),(16,420,1,1,0,1490231286,0,0,0,0,0,0,0,0),(16,432,1,1,0,1490247589,6,0,0,0,0,0,0,0),(16,433,1,1,0,1490247589,10,0,0,0,0,0,0,0),(16,436,1,0,0,1490249596,0,0,0,0,0,0,0,0),(16,1339,1,0,0,1490249596,0,0,0,0,0,0,0,0),(16,1599,1,1,0,1490231286,0,0,0,0,0,0,0,0),(16,1688,1,1,0,1490245788,0,0,0,0,0,0,0,0),(16,1689,1,1,0,1490246689,1,0,0,0,0,0,0,0),(16,1715,1,1,0,1490244888,0,0,0,0,0,0,0,0),(16,2039,1,0,0,1490244888,0,0,0,0,0,0,0,0),(16,2160,1,1,0,1490231286,0,0,0,0,0,0,0,0),(16,3115,1,1,0,1490230386,0,0,0,0,0,0,0,0),(16,3361,1,1,0,1490230386,0,0,0,0,0,0,0,0),(16,3364,1,1,0,1490230552,0,0,0,0,0,0,0,0),(16,3365,1,1,0,1490231286,0,0,0,0,0,0,0,0),(16,5541,0,0,0,1490246689,0,0,0,0,1,0,0,0),(16,6387,1,1,0,1490249596,0,0,0,0,0,0,0,0),(16,6391,1,0,0,1490249596,0,0,0,0,1,0,0,0),(16,6661,1,1,0,1490244888,5,0,0,0,0,0,0,0),(16,6662,1,1,0,1490244888,0,0,0,0,0,0,0,0),(18,8325,1,1,0,1490249599,8,0,0,0,0,0,0,0),(18,8326,1,1,0,1490309218,0,0,0,0,0,0,0,0),(18,8327,1,1,0,1490311387,0,0,0,0,0,0,0,0),(18,8330,1,1,0,1490311387,0,0,0,0,0,0,0,0),(18,8334,1,1,0,1490311387,7,7,0,0,0,0,0,0),(18,8335,1,0,0,1490311387,8,2,0,0,0,0,1,0),(18,8336,1,1,0,1490309218,0,0,0,0,0,0,0,0),(18,8338,1,0,0,1490311387,0,0,0,0,1,0,0,0),(18,8345,1,1,0,1490309218,1,0,0,0,0,0,0,0),(18,8346,1,1,0,1490309218,6,0,0,0,0,0,0,0),(18,9676,1,1,0,1490249599,0,0,0,0,0,0,0,0),(18,10068,1,1,0,1490249599,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `character_queststatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_queststatus_daily`
--

DROP TABLE IF EXISTS `character_queststatus_daily`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_queststatus_daily` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  PRIMARY KEY (`guid`,`quest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_queststatus_daily`
--

LOCK TABLES `character_queststatus_daily` WRITE;
/*!40000 ALTER TABLE `character_queststatus_daily` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_queststatus_daily` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_queststatus_monthly`
--

DROP TABLE IF EXISTS `character_queststatus_monthly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_queststatus_monthly` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  PRIMARY KEY (`guid`,`quest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_queststatus_monthly`
--

LOCK TABLES `character_queststatus_monthly` WRITE;
/*!40000 ALTER TABLE `character_queststatus_monthly` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_queststatus_monthly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_queststatus_weekly`
--

DROP TABLE IF EXISTS `character_queststatus_weekly`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_queststatus_weekly` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `quest` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Quest Identifier',
  PRIMARY KEY (`guid`,`quest`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_queststatus_weekly`
--

LOCK TABLES `character_queststatus_weekly` WRITE;
/*!40000 ALTER TABLE `character_queststatus_weekly` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_queststatus_weekly` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_reputation`
--

DROP TABLE IF EXISTS `character_reputation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_reputation` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `faction` int(11) unsigned NOT NULL DEFAULT '0',
  `standing` int(11) NOT NULL DEFAULT '0',
  `flags` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`faction`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_reputation`
--

LOCK TABLES `character_reputation` WRITE;
/*!40000 ALTER TABLE `character_reputation` DISABLE KEYS */;
INSERT INTO `character_reputation` VALUES (1,21,0,0),(1,46,0,4),(1,47,0,17),(1,54,0,17),(1,59,0,16),(1,67,0,14),(1,68,0,6),(1,69,0,17),(1,70,0,2),(1,72,0,17),(1,76,0,6),(1,81,0,6),(1,83,0,4),(1,86,0,4),(1,87,0,2),(1,92,0,2),(1,93,0,2),(1,169,0,8),(1,270,0,16),(1,289,0,4),(1,349,0,0),(1,369,0,0),(1,469,0,25),(1,470,0,0),(1,471,0,20),(1,509,0,17),(1,510,0,2),(1,529,0,0),(1,530,0,6),(1,549,0,4),(1,550,0,4),(1,551,0,4),(1,569,0,4),(1,570,0,4),(1,571,0,4),(1,574,0,4),(1,576,0,2),(1,577,0,0),(1,589,0,0),(1,609,0,0),(1,729,0,2),(1,730,0,17),(1,749,0,0),(1,809,0,16),(1,889,0,6),(1,890,0,17),(1,891,0,24),(1,892,0,14),(1,909,0,16),(1,910,0,2),(1,911,0,6),(1,922,0,6),(1,930,0,17),(1,932,0,80),(1,933,0,16),(1,934,0,80),(1,935,0,16),(1,936,0,28),(1,941,0,6),(1,942,0,16),(1,946,0,16),(1,947,0,2),(1,967,194,17),(1,970,0,0),(1,978,0,16),(1,980,0,8),(1,989,0,16),(1,990,0,16),(1,1005,0,4),(1,1011,0,16),(1,1012,0,16),(1,1015,0,2),(1,1031,0,16),(1,1038,0,16),(1,1077,0,16),(3,21,0,0),(3,46,0,4),(3,47,40,17),(3,54,40,17),(3,59,0,16),(3,67,0,14),(3,68,0,6),(3,69,40,17),(3,70,0,2),(3,72,164,17),(3,76,0,6),(3,81,0,6),(3,83,0,4),(3,86,0,4),(3,87,0,2),(3,92,0,2),(3,93,0,3),(3,169,0,8),(3,270,0,16),(3,289,0,4),(3,349,0,0),(3,369,0,0),(3,469,0,25),(3,470,0,0),(3,471,0,20),(3,509,0,16),(3,510,0,2),(3,529,0,0),(3,530,0,6),(3,549,0,4),(3,550,0,4),(3,551,0,4),(3,569,0,4),(3,570,0,4),(3,571,0,4),(3,574,0,4),(3,576,0,2),(3,577,0,0),(3,589,0,0),(3,609,0,0),(3,729,0,2),(3,730,0,16),(3,749,0,0),(3,809,0,16),(3,889,0,6),(3,890,0,16),(3,891,0,24),(3,892,0,14),(3,909,0,16),(3,910,0,2),(3,911,0,6),(3,922,0,6),(3,930,40,17),(3,932,0,80),(3,933,0,16),(3,934,0,80),(3,935,0,16),(3,936,0,28),(3,941,0,6),(3,942,0,16),(3,946,3,17),(3,947,0,2),(3,967,103,17),(3,970,0,0),(3,978,0,16),(3,980,0,8),(3,989,0,16),(3,990,0,16),(3,1005,0,4),(3,1011,0,16),(3,1012,0,16),(3,1015,0,2),(3,1031,0,16),(3,1038,0,16),(3,1077,0,16),(6,21,0,0),(6,46,0,4),(6,47,0,6),(6,54,0,6),(6,59,0,16),(6,67,0,25),(6,68,829,17),(6,69,0,6),(6,70,0,2),(6,72,0,6),(6,76,829,17),(6,81,829,17),(6,83,0,4),(6,86,0,4),(6,87,0,2),(6,92,0,2),(6,93,0,2),(6,169,0,8),(6,270,0,16),(6,289,0,4),(6,349,0,0),(6,369,0,0),(6,469,0,14),(6,470,0,1),(6,471,0,22),(6,509,0,2),(6,510,0,16),(6,529,0,0),(6,530,829,17),(6,549,0,4),(6,550,0,4),(6,551,0,4),(6,569,0,4),(6,570,0,4),(6,571,0,4),(6,574,0,4),(6,576,0,2),(6,577,0,0),(6,589,0,6),(6,609,0,0),(6,729,0,17),(6,730,0,2),(6,749,0,0),(6,809,0,16),(6,889,0,16),(6,890,0,6),(6,891,0,0),(6,892,0,24),(6,909,0,16),(6,910,0,2),(6,911,3355,17),(6,922,0,16),(6,930,0,6),(6,932,0,80),(6,933,0,16),(6,934,0,80),(6,935,0,16),(6,936,0,28),(6,941,0,16),(6,942,0,16),(6,946,0,2),(6,947,0,16),(6,967,0,16),(6,970,0,0),(6,978,0,2),(6,980,0,8),(6,989,0,16),(6,990,0,16),(6,1005,0,4),(6,1011,0,16),(6,1012,0,16),(6,1015,0,2),(6,1031,0,16),(6,1038,0,16),(6,1077,0,16),(7,21,0,0),(7,46,0,4),(7,47,750,17),(7,54,750,17),(7,59,0,16),(7,67,0,14),(7,68,0,6),(7,69,750,17),(7,70,0,2),(7,72,3044,17),(7,76,0,6),(7,81,0,6),(7,83,0,4),(7,86,0,4),(7,87,0,2),(7,92,0,2),(7,93,0,2),(7,169,0,8),(7,270,0,16),(7,289,0,4),(7,349,0,0),(7,369,0,0),(7,469,0,25),(7,470,0,0),(7,471,0,20),(7,509,0,17),(7,510,0,2),(7,529,0,0),(7,530,0,6),(7,549,0,4),(7,550,0,4),(7,551,0,4),(7,569,0,4),(7,570,0,4),(7,571,0,4),(7,574,0,4),(7,576,0,2),(7,577,0,0),(7,589,0,0),(7,609,0,0),(7,729,0,2),(7,730,0,17),(7,749,0,0),(7,809,0,16),(7,889,0,6),(7,890,0,17),(7,891,0,24),(7,892,0,14),(7,909,0,16),(7,910,0,2),(7,911,0,6),(7,922,0,6),(7,930,750,17),(7,932,0,80),(7,933,0,16),(7,934,0,80),(7,935,0,16),(7,936,0,28),(7,941,0,6),(7,942,0,16),(7,946,0,16),(7,947,0,2),(7,967,0,16),(7,970,0,0),(7,978,0,16),(7,980,0,8),(7,989,0,16),(7,990,0,16),(7,1005,0,4),(7,1011,0,16),(7,1012,0,16),(7,1015,0,2),(7,1031,0,16),(7,1038,0,16),(7,1077,0,16),(8,21,0,0),(8,46,0,4),(8,47,952,17),(8,54,952,17),(8,59,0,16),(8,67,0,14),(8,68,0,6),(8,69,952,17),(8,70,0,2),(8,72,3867,17),(8,76,0,6),(8,81,0,6),(8,83,0,4),(8,86,0,4),(8,87,0,2),(8,92,0,2),(8,93,0,2),(8,169,0,8),(8,270,0,16),(8,289,0,4),(8,349,0,0),(8,369,0,0),(8,469,0,25),(8,470,0,0),(8,471,0,20),(8,509,0,16),(8,510,0,2),(8,529,0,0),(8,530,0,6),(8,549,0,4),(8,550,0,4),(8,551,0,4),(8,569,0,4),(8,570,0,4),(8,571,0,4),(8,574,0,4),(8,576,0,2),(8,577,0,0),(8,589,0,0),(8,609,0,0),(8,729,0,2),(8,730,0,16),(8,749,0,0),(8,809,0,16),(8,889,0,6),(8,890,0,16),(8,891,0,24),(8,892,0,14),(8,909,0,16),(8,910,0,2),(8,911,0,6),(8,922,0,6),(8,930,952,17),(8,932,0,80),(8,933,0,16),(8,934,0,80),(8,935,0,16),(8,936,0,28),(8,941,0,6),(8,942,0,16),(8,946,0,16),(8,947,0,2),(8,967,0,16),(8,970,0,0),(8,978,0,16),(8,980,0,8),(8,989,0,16),(8,990,0,16),(8,1005,0,4),(8,1011,0,16),(8,1012,0,16),(8,1015,0,2),(8,1031,0,16),(8,1038,0,16),(8,1077,0,16),(10,21,0,0),(10,46,0,4),(10,47,0,6),(10,54,0,6),(10,59,0,16),(10,67,0,25),(10,68,0,17),(10,69,0,6),(10,70,0,2),(10,72,0,6),(10,76,0,17),(10,81,0,17),(10,83,0,4),(10,86,0,4),(10,87,0,2),(10,92,0,2),(10,93,0,3),(10,169,0,8),(10,270,0,16),(10,289,0,4),(10,349,0,0),(10,369,0,0),(10,469,0,14),(10,470,0,0),(10,471,0,22),(10,509,0,2),(10,510,0,16),(10,529,0,0),(10,530,0,17),(10,549,0,4),(10,550,0,4),(10,551,0,4),(10,569,0,4),(10,570,0,4),(10,571,0,4),(10,574,0,4),(10,576,0,2),(10,577,0,0),(10,589,0,6),(10,609,0,0),(10,729,0,16),(10,730,0,2),(10,749,0,0),(10,809,0,16),(10,889,0,16),(10,890,0,6),(10,891,0,14),(10,892,0,24),(10,909,0,16),(10,910,0,2),(10,911,0,17),(10,922,0,16),(10,930,0,6),(10,932,0,80),(10,933,0,16),(10,934,0,80),(10,935,0,16),(10,936,0,28),(10,941,0,16),(10,942,0,16),(10,946,0,2),(10,947,0,16),(10,967,0,16),(10,970,0,0),(10,978,0,2),(10,980,0,8),(10,989,0,16),(10,990,0,16),(10,1005,0,4),(10,1011,0,16),(10,1012,0,16),(10,1015,0,2),(10,1031,0,16),(10,1038,0,16),(10,1077,0,16),(11,21,0,0),(11,46,0,4),(11,47,0,17),(11,54,0,17),(11,59,0,16),(11,67,0,14),(11,68,0,6),(11,69,0,17),(11,70,0,2),(11,72,0,17),(11,76,0,6),(11,81,0,6),(11,83,0,4),(11,86,0,4),(11,87,0,2),(11,92,0,2),(11,93,0,2),(11,169,0,8),(11,270,0,16),(11,289,0,4),(11,349,0,0),(11,369,0,0),(11,469,0,25),(11,470,0,0),(11,471,0,20),(11,509,0,16),(11,510,0,2),(11,529,0,0),(11,530,0,6),(11,549,0,4),(11,550,0,4),(11,551,0,4),(11,569,0,4),(11,570,0,4),(11,571,0,4),(11,574,0,4),(11,576,0,2),(11,577,0,0),(11,589,0,0),(11,609,0,0),(11,729,0,2),(11,730,0,16),(11,749,0,0),(11,809,0,16),(11,889,0,6),(11,890,0,16),(11,891,0,24),(11,892,0,14),(11,909,0,16),(11,910,0,2),(11,911,0,6),(11,922,0,6),(11,930,0,17),(11,932,0,80),(11,933,0,16),(11,934,0,80),(11,935,0,16),(11,936,0,28),(11,941,0,6),(11,942,0,16),(11,946,0,16),(11,947,0,2),(11,967,0,16),(11,970,0,0),(11,978,0,16),(11,980,0,8),(11,989,0,16),(11,990,0,16),(11,1005,0,4),(11,1011,0,16),(11,1012,0,16),(11,1015,0,2),(11,1031,0,16),(11,1038,0,16),(11,1077,0,16),(15,21,0,0),(15,46,0,4),(15,47,0,17),(15,54,0,17),(15,59,0,16),(15,67,0,14),(15,68,0,6),(15,69,0,17),(15,70,0,2),(15,72,0,17),(15,76,0,6),(15,81,0,6),(15,83,0,4),(15,86,0,4),(15,87,0,2),(15,92,0,2),(15,93,0,2),(15,169,0,8),(15,270,0,16),(15,289,0,4),(15,349,0,0),(15,369,0,0),(15,469,0,25),(15,470,0,0),(15,471,0,20),(15,509,0,16),(15,510,0,2),(15,529,0,0),(15,530,0,6),(15,549,0,4),(15,550,0,4),(15,551,0,4),(15,569,0,4),(15,570,0,4),(15,571,0,4),(15,574,0,4),(15,576,0,2),(15,577,0,0),(15,589,0,0),(15,609,0,0),(15,729,0,2),(15,730,0,16),(15,749,0,0),(15,809,0,16),(15,889,0,6),(15,890,0,16),(15,891,0,24),(15,892,0,14),(15,909,0,16),(15,910,0,0),(15,911,0,6),(15,922,0,6),(15,930,0,17),(15,932,0,80),(15,933,0,16),(15,934,0,80),(15,935,0,16),(15,936,0,28),(15,941,0,6),(15,942,0,16),(15,946,0,16),(15,947,0,0),(15,967,0,16),(15,970,0,0),(15,978,0,16),(15,980,0,8),(15,989,0,16),(15,990,0,16),(15,1005,0,4),(15,1011,0,16),(15,1012,0,16),(15,1015,0,2),(15,1031,0,16),(15,1038,0,16),(15,1077,0,16),(16,21,0,0),(16,46,0,4),(16,47,7845,17),(16,54,7769,17),(16,59,0,16),(16,67,0,14),(16,68,0,6),(16,69,3094,17),(16,70,0,2),(16,72,3094,17),(16,76,0,6),(16,81,0,6),(16,83,0,4),(16,86,0,4),(16,87,0,2),(16,92,0,2),(16,93,0,2),(16,169,0,8),(16,270,0,16),(16,289,0,4),(16,349,0,0),(16,369,0,0),(16,469,0,25),(16,470,0,0),(16,471,0,20),(16,509,0,16),(16,510,0,2),(16,529,0,1),(16,530,0,6),(16,549,0,4),(16,550,0,4),(16,551,0,4),(16,569,0,4),(16,570,0,4),(16,571,0,4),(16,574,0,4),(16,576,0,2),(16,577,0,0),(16,589,0,0),(16,609,0,0),(16,729,0,2),(16,730,0,16),(16,749,0,0),(16,809,0,16),(16,889,0,6),(16,890,0,16),(16,891,0,24),(16,892,0,14),(16,909,0,16),(16,910,0,2),(16,911,0,6),(16,922,0,6),(16,930,3094,17),(16,932,0,80),(16,933,0,16),(16,934,0,80),(16,935,0,16),(16,936,0,28),(16,941,0,6),(16,942,0,16),(16,946,0,16),(16,947,0,2),(16,967,0,16),(16,970,0,0),(16,978,0,16),(16,980,0,8),(16,989,0,16),(16,990,0,16),(16,1005,0,4),(16,1011,0,16),(16,1012,0,16),(16,1015,0,2),(16,1031,0,16),(16,1038,0,16),(16,1077,0,16),(17,21,0,0),(17,46,0,4),(17,47,0,6),(17,54,0,6),(17,59,0,16),(17,67,0,25),(17,68,0,17),(17,69,0,6),(17,70,0,2),(17,72,0,6),(17,76,0,17),(17,81,0,17),(17,83,0,4),(17,86,0,4),(17,87,0,2),(17,92,0,2),(17,93,0,2),(17,169,0,8),(17,270,0,16),(17,289,0,4),(17,349,0,0),(17,369,0,0),(17,469,0,14),(17,470,0,0),(17,471,0,22),(17,509,0,2),(17,510,0,16),(17,529,0,0),(17,530,0,17),(17,549,0,4),(17,550,0,4),(17,551,0,4),(17,569,0,4),(17,570,0,4),(17,571,0,4),(17,574,0,4),(17,576,0,2),(17,577,0,0),(17,589,0,6),(17,609,0,0),(17,729,0,16),(17,730,0,2),(17,749,0,0),(17,809,0,16),(17,889,0,16),(17,890,0,6),(17,891,0,14),(17,892,0,24),(17,909,0,16),(17,910,0,0),(17,911,0,17),(17,922,0,16),(17,930,0,6),(17,932,0,80),(17,933,0,16),(17,934,0,80),(17,935,0,16),(17,936,0,28),(17,941,0,16),(17,942,0,16),(17,946,0,0),(17,947,0,16),(17,967,0,16),(17,970,0,0),(17,978,0,0),(17,980,0,8),(17,989,0,16),(17,990,0,16),(17,1005,0,4),(17,1011,0,16),(17,1012,0,16),(17,1015,0,2),(17,1031,0,16),(17,1038,0,16),(17,1077,0,16),(18,21,0,0),(18,46,0,4),(18,47,0,6),(18,54,0,6),(18,59,0,16),(18,67,0,25),(18,68,456,17),(18,69,0,6),(18,70,0,2),(18,72,0,6),(18,76,456,17),(18,81,456,17),(18,83,0,4),(18,86,0,4),(18,87,0,2),(18,92,0,2),(18,93,0,2),(18,169,0,8),(18,270,0,16),(18,289,0,4),(18,349,0,0),(18,369,0,0),(18,469,0,14),(18,470,0,0),(18,471,0,22),(18,509,0,2),(18,510,0,16),(18,529,0,0),(18,530,456,17),(18,549,0,4),(18,550,0,4),(18,551,0,4),(18,569,0,4),(18,570,0,4),(18,571,0,4),(18,574,0,4),(18,576,0,2),(18,577,0,0),(18,589,0,6),(18,609,0,0),(18,729,0,16),(18,730,0,2),(18,749,0,0),(18,809,0,16),(18,889,0,16),(18,890,0,6),(18,891,0,0),(18,892,0,24),(18,909,0,16),(18,910,0,2),(18,911,1845,17),(18,922,0,16),(18,930,0,6),(18,932,0,80),(18,933,0,16),(18,934,0,80),(18,935,0,16),(18,936,0,28),(18,941,0,16),(18,942,0,16),(18,946,0,2),(18,947,0,16),(18,967,0,16),(18,970,0,0),(18,978,0,2),(18,980,0,8),(18,989,0,16),(18,990,0,16),(18,1005,0,4),(18,1011,0,16),(18,1012,0,16),(18,1015,0,2),(18,1031,0,16),(18,1038,0,16),(18,1077,0,16);
/*!40000 ALTER TABLE `character_reputation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_skills`
--

DROP TABLE IF EXISTS `character_skills`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_skills` (
  `guid` int(11) unsigned NOT NULL COMMENT 'Global Unique Identifier',
  `skill` mediumint(9) unsigned NOT NULL,
  `value` mediumint(9) unsigned NOT NULL,
  `max` mediumint(9) unsigned NOT NULL,
  PRIMARY KEY (`guid`,`skill`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_skills`
--

LOCK TABLES `character_skills` WRITE;
/*!40000 ALTER TABLE `character_skills` DISABLE KEYS */;
INSERT INTO `character_skills` VALUES (1,6,1,1),(1,8,1,1),(1,95,11,350),(1,98,300,300),(1,136,1,350),(1,162,1,350),(1,228,1,350),(1,415,1,1),(3,38,1,1),(3,95,8,5),(3,98,300,300),(3,162,1,5),(3,173,9,5),(3,176,1,5),(3,253,1,1),(3,414,1,1),(3,415,1,1),(6,45,29,50),(6,51,1,1),(6,95,34,50),(6,109,300,300),(6,129,1,75),(6,137,300,300),(6,162,1,50),(6,163,1,1),(6,173,32,50),(6,356,1,75),(6,414,1,1),(6,415,1,1),(6,756,1,1),(7,38,1,1),(7,43,31,35),(7,95,30,35),(7,98,300,300),(7,129,8,75),(7,162,20,35),(7,173,20,35),(7,176,22,35),(7,182,2,75),(7,186,4,75),(7,253,1,1),(7,414,1,1),(7,415,1,1),(8,26,1,1),(8,43,41,50),(8,44,1,50),(8,54,1,50),(8,95,43,50),(8,98,300,300),(8,129,23,75),(8,162,1,50),(8,393,32,75),(8,413,1,1),(8,414,1,1),(8,415,1,1),(8,433,1,1),(9,26,1,1),(9,43,1,5),(9,54,1,5),(9,95,1,5),(9,98,300,300),(9,113,300,300),(9,162,1,5),(9,173,1,5),(9,413,1,1),(9,414,1,1),(9,415,1,1),(9,433,1,1),(10,44,39,50),(10,45,20,50),(10,51,1,1),(10,95,39,50),(10,109,300,300),(10,162,1,50),(10,163,1,1),(10,414,1,1),(10,415,1,1),(11,26,1,1),(11,43,350,350),(11,44,350,350),(11,46,350,350),(11,54,350,350),(11,55,350,350),(11,95,350,350),(11,98,300,300),(11,118,350,350),(11,136,350,350),(11,160,350,350),(11,162,350,350),(11,172,350,350),(11,173,350,350),(11,226,350,350),(11,229,350,350),(11,293,1,1),(11,313,300,300),(11,413,1,1),(11,414,1,1),(11,415,1,1),(11,433,1,1),(11,473,1,1),(11,762,150,150),(15,95,4,20),(15,98,300,300),(15,162,1,20),(15,173,5,20),(15,228,1,20),(15,313,300,300),(15,354,1,1),(15,415,1,1),(15,593,1,1),(16,95,58,70),(16,98,300,300),(16,162,1,70),(16,173,56,70),(16,228,1,70),(16,313,300,300),(16,354,1,1),(16,415,1,1),(16,593,1,1),(17,26,1,1),(17,43,1,5),(17,55,1,5),(17,95,1,5),(17,109,300,300),(17,162,1,5),(17,173,1,5),(17,413,1,1),(17,414,1,1),(17,415,1,1),(17,433,1,1),(17,673,300,300),(17,760,1,1),(18,43,27,30),(18,55,22,30),(18,95,24,30),(18,109,300,300),(18,137,300,300),(18,162,1,30),(18,413,1,1),(18,414,1,1),(18,415,1,1),(18,433,1,1),(18,594,1,1),(18,756,1,1);
/*!40000 ALTER TABLE `character_skills` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_social`
--

DROP TABLE IF EXISTS `character_social`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_social` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `friend` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Friend Global Unique Identifier',
  `flags` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Friend Flags',
  `note` varchar(48) NOT NULL DEFAULT '' COMMENT 'Friend Note',
  PRIMARY KEY (`guid`,`friend`,`flags`),
  KEY `guid_flags` (`guid`,`flags`),
  KEY `friend_flags` (`friend`,`flags`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_social`
--

LOCK TABLES `character_social` WRITE;
/*!40000 ALTER TABLE `character_social` DISABLE KEYS */;
INSERT INTO `character_social` VALUES (11,7,1,'');
/*!40000 ALTER TABLE `character_social` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_spell`
--

DROP TABLE IF EXISTS `character_spell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_spell` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `spell` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `active` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `disabled` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`),
  KEY `Idx_spell` (`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_spell`
--

LOCK TABLES `character_spell` WRITE;
/*!40000 ALTER TABLE `character_spell` DISABLE KEYS */;
INSERT INTO `character_spell` VALUES (1,120,1,0),(1,130,1,0),(1,475,1,0),(1,759,1,0),(1,865,1,0),(1,990,1,0),(1,1461,1,0),(1,1953,1,0),(1,2121,1,0),(1,2139,1,0),(1,3561,1,0),(1,3562,1,0),(1,3565,1,0),(1,5145,1,0),(1,6127,1,0),(1,6141,1,0),(1,6143,1,0),(1,7301,1,0),(1,7302,1,0),(1,8401,1,0),(1,8406,1,0),(1,8412,1,0),(1,8438,1,0),(1,8444,1,0),(1,8450,1,0),(1,8455,1,0),(1,8457,1,0),(1,8494,1,0),(1,12051,1,0),(1,12824,1,0),(1,45438,1,0),(6,883,1,0),(6,1130,1,0),(6,1515,1,0),(6,2641,1,0),(6,3044,1,0),(6,3273,1,0),(6,5116,1,0),(6,7620,1,0),(6,13163,1,0),(6,13165,1,0),(6,13549,1,0),(6,14260,1,0),(7,53,1,0),(7,201,1,0),(7,921,1,0),(7,1757,1,0),(7,1776,1,0),(7,1784,1,0),(7,2366,1,0),(7,2575,1,0),(7,3273,1,0),(8,71,1,0),(8,100,1,0),(8,284,1,0),(8,355,1,0),(8,1715,1,0),(8,2687,1,0),(8,3127,1,0),(8,3273,1,0),(8,6343,1,0),(8,6546,1,0),(8,6673,1,0),(8,7386,1,0),(8,8613,1,0),(8,12286,1,0),(11,196,1,0),(11,197,1,0),(11,199,1,0),(11,200,1,0),(11,202,1,0),(11,227,1,0),(11,266,1,0),(11,469,1,0),(11,674,1,0),(11,676,1,0),(11,750,1,0),(11,871,1,0),(11,1161,1,0),(11,1680,1,0),(11,1719,1,0),(11,2048,1,0),(11,2565,1,0),(11,2687,1,0),(11,3127,1,0),(11,3411,1,0),(11,5011,1,0),(11,5246,1,0),(11,6554,1,0),(11,11578,1,0),(11,11585,1,0),(11,12292,1,0),(11,12296,1,0),(11,12321,1,0),(11,12323,1,0),(11,12664,1,0),(11,12678,1,0),(11,12714,1,0),(11,12815,1,0),(11,12856,1,0),(11,12867,1,0),(11,12962,1,0),(11,12963,1,0),(11,13002,1,0),(11,13048,1,0),(11,15590,1,0),(11,16463,1,0),(11,16492,1,0),(11,16494,1,0),(11,18499,1,0),(11,20230,1,0),(11,23920,1,0),(11,25203,1,0),(11,25208,1,0),(11,25212,1,0),(11,25231,1,0),(11,25236,1,0),(11,25242,1,0),(11,25264,1,0),(11,25266,1,0),(11,29623,1,0),(11,29704,1,0),(11,29707,1,0),(11,29838,1,0),(11,29859,1,0),(11,29888,1,0),(11,30330,1,0),(11,30357,1,0),(11,33391,1,0),(11,34428,1,0),(11,35451,1,0),(15,172,1,0),(15,348,1,0),(15,695,1,0),(15,702,1,0),(15,1454,1,0),(16,172,1,0),(16,688,1,0),(16,696,1,0),(16,697,1,0),(16,705,1,0),(16,707,1,0),(16,755,1,0),(16,980,1,0),(16,1108,1,0),(16,1120,1,0),(16,1454,1,0),(16,5782,1,0),(16,6201,1,0),(16,17814,1,0),(18,465,1,0),(18,19740,1,0),(18,20271,1,0);
/*!40000 ALTER TABLE `character_spell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_spell_cooldown`
--

DROP TABLE IF EXISTS `character_spell_cooldown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_spell_cooldown` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier, Low part',
  `spell` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `item` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Item Identifier',
  `time` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_spell_cooldown`
--

LOCK TABLES `character_spell_cooldown` WRITE;
/*!40000 ALTER TABLE `character_spell_cooldown` DISABLE KEYS */;
INSERT INTO `character_spell_cooldown` VALUES (6,8690,6948,1490205179),(6,39937,28585,1490205179);
/*!40000 ALTER TABLE `character_spell_cooldown` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_stats`
--

DROP TABLE IF EXISTS `character_stats`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_stats` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier, Low part',
  `maxhealth` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower1` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower2` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower3` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower4` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower5` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower6` int(10) unsigned NOT NULL DEFAULT '0',
  `maxpower7` int(10) unsigned NOT NULL DEFAULT '0',
  `strength` int(10) unsigned NOT NULL DEFAULT '0',
  `agility` int(10) unsigned NOT NULL DEFAULT '0',
  `stamina` int(10) unsigned NOT NULL DEFAULT '0',
  `intellect` int(10) unsigned NOT NULL DEFAULT '0',
  `spirit` int(10) unsigned NOT NULL DEFAULT '0',
  `armor` int(10) unsigned NOT NULL DEFAULT '0',
  `resHoly` int(10) unsigned NOT NULL DEFAULT '0',
  `resFire` int(10) unsigned NOT NULL DEFAULT '0',
  `resNature` int(10) unsigned NOT NULL DEFAULT '0',
  `resFrost` int(10) unsigned NOT NULL DEFAULT '0',
  `resShadow` int(10) unsigned NOT NULL DEFAULT '0',
  `resArcane` int(10) unsigned NOT NULL DEFAULT '0',
  `blockPct` float unsigned NOT NULL DEFAULT '0',
  `dodgePct` float unsigned NOT NULL DEFAULT '0',
  `parryPct` float unsigned NOT NULL DEFAULT '0',
  `critPct` float unsigned NOT NULL DEFAULT '0',
  `rangedCritPct` float unsigned NOT NULL DEFAULT '0',
  `spellCritPct` float unsigned NOT NULL DEFAULT '0',
  `attackPower` int(10) unsigned NOT NULL DEFAULT '0',
  `rangedAttackPower` int(10) unsigned NOT NULL DEFAULT '0',
  `spellPower` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_stats`
--

LOCK TABLES `character_stats` WRITE;
/*!40000 ALTER TABLE `character_stats` DISABLE KEYS */;
/*!40000 ALTER TABLE `character_stats` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_ticket`
--

DROP TABLE IF EXISTS `character_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_ticket` (
  `ticket_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `guid` int(11) unsigned NOT NULL DEFAULT '0',
  `ticket_text` text,
  `response_text` text,
  `ticket_lastchange` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ticket_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_ticket`
--

LOCK TABLES `character_ticket` WRITE;
/*!40000 ALTER TABLE `character_ticket` DISABLE KEYS */;
INSERT INTO `character_ticket` VALUES (1,17,'test you nig','','2017-03-23 02:42:15');
/*!40000 ALTER TABLE `character_ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `character_tutorial`
--

DROP TABLE IF EXISTS `character_tutorial`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `character_tutorial` (
  `account` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Account Identifier',
  `tut0` int(11) unsigned NOT NULL DEFAULT '0',
  `tut1` int(11) unsigned NOT NULL DEFAULT '0',
  `tut2` int(11) unsigned NOT NULL DEFAULT '0',
  `tut3` int(11) unsigned NOT NULL DEFAULT '0',
  `tut4` int(11) unsigned NOT NULL DEFAULT '0',
  `tut5` int(11) unsigned NOT NULL DEFAULT '0',
  `tut6` int(11) unsigned NOT NULL DEFAULT '0',
  `tut7` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`account`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `character_tutorial`
--

LOCK TABLES `character_tutorial` WRITE;
/*!40000 ALTER TABLE `character_tutorial` DISABLE KEYS */;
INSERT INTO `character_tutorial` VALUES (5,4333574,512,0,0,0,0,0,0),(8,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295),(9,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295),(10,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295),(12,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295),(13,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295),(16,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295,4294967295);
/*!40000 ALTER TABLE `character_tutorial` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `characters`
--

DROP TABLE IF EXISTS `characters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `characters` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `account` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Account Identifier',
  `name` varchar(12) NOT NULL DEFAULT '',
  `race` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `class` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `gender` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `level` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `xp` int(10) unsigned NOT NULL DEFAULT '0',
  `money` int(10) unsigned NOT NULL DEFAULT '0',
  `playerBytes` int(10) unsigned NOT NULL DEFAULT '0',
  `playerBytes2` int(10) unsigned NOT NULL DEFAULT '0',
  `playerFlags` int(10) unsigned NOT NULL DEFAULT '0',
  `position_x` float NOT NULL DEFAULT '0',
  `position_y` float NOT NULL DEFAULT '0',
  `position_z` float NOT NULL DEFAULT '0',
  `map` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Map Identifier',
  `dungeon_difficulty` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `orientation` float NOT NULL DEFAULT '0',
  `taximask` longtext,
  `online` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `cinematic` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `totaltime` int(11) unsigned NOT NULL DEFAULT '0',
  `leveltime` int(11) unsigned NOT NULL DEFAULT '0',
  `logout_time` bigint(20) unsigned NOT NULL DEFAULT '0',
  `is_logout_resting` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `rest_bonus` float NOT NULL DEFAULT '0',
  `resettalents_cost` int(11) unsigned NOT NULL DEFAULT '0',
  `resettalents_time` bigint(20) unsigned NOT NULL DEFAULT '0',
  `trans_x` float NOT NULL DEFAULT '0',
  `trans_y` float NOT NULL DEFAULT '0',
  `trans_z` float NOT NULL DEFAULT '0',
  `trans_o` float NOT NULL DEFAULT '0',
  `transguid` bigint(20) unsigned NOT NULL DEFAULT '0',
  `extra_flags` int(11) unsigned NOT NULL DEFAULT '0',
  `stable_slots` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `at_login` int(11) unsigned NOT NULL DEFAULT '0',
  `zone` int(11) unsigned NOT NULL DEFAULT '0',
  `death_expire_time` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxi_path` text,
  `arenaPoints` int(10) unsigned NOT NULL DEFAULT '0',
  `totalHonorPoints` int(10) unsigned NOT NULL DEFAULT '0',
  `todayHonorPoints` int(10) unsigned NOT NULL DEFAULT '0',
  `yesterdayHonorPoints` int(10) unsigned NOT NULL DEFAULT '0',
  `totalKills` int(10) unsigned NOT NULL DEFAULT '0',
  `todayKills` smallint(5) unsigned NOT NULL DEFAULT '0',
  `yesterdayKills` smallint(5) unsigned NOT NULL DEFAULT '0',
  `chosenTitle` int(10) unsigned NOT NULL DEFAULT '0',
  `watchedFaction` int(10) unsigned NOT NULL DEFAULT '0',
  `drunk` smallint(5) unsigned NOT NULL DEFAULT '0',
  `health` int(10) unsigned NOT NULL DEFAULT '0',
  `power1` int(10) unsigned NOT NULL DEFAULT '0',
  `power2` int(10) unsigned NOT NULL DEFAULT '0',
  `power3` int(10) unsigned NOT NULL DEFAULT '0',
  `power4` int(10) unsigned NOT NULL DEFAULT '0',
  `power5` int(10) unsigned NOT NULL DEFAULT '0',
  `exploredZones` longtext,
  `equipmentCache` longtext,
  `ammoId` int(10) unsigned NOT NULL DEFAULT '0',
  `knownTitles` longtext,
  `actionBars` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `deleteInfos_Account` int(11) unsigned DEFAULT NULL,
  `deleteInfos_Name` varchar(12) DEFAULT NULL,
  `deleteDate` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`guid`),
  KEY `idx_account` (`account`),
  KEY `idx_online` (`online`),
  KEY `idx_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Player System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `characters`
--

LOCK TABLES `characters` WRITE;
/*!40000 ALTER TABLE `characters` DISABLE KEYS */;
INSERT INTO `characters` VALUES (1,5,'Xtb',1,8,1,70,0,854708,118490629,33554434,40,-8830.05,628.891,94.0652,0,0,5.36152,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 0 0 ',0,1,3631,2639,1490203130,1,0,0,0,0,0,0,0,0,3,0,0,1519,1490169355,'',0,0,0,0,0,0,0,0,2147483647,0,3723,4496,0,0,100,0,'1 0 16777216 1610612736 4096 0 16 0 0 0 0 0 0 0 0 0 0 4112 0 0 0 8454152 0 0 0 0 0 0 0 8388608 0 0 0 536870912 1048576 0 17408 0 0 0 32768 32768 0 0 33554432 0 0 0 0 16384 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 6096 0 0 0 30673 0 0 0 55 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 0 0 0 0 0 0 0 ',0,'0 0 ',0,NULL,NULL,NULL),(3,8,'Dantedude',1,4,1,1,0,121659,16778247,16777222,40,-4824.35,-978.091,464.708,0,0,3.93988,'2 0 0 8 0 0 1048576 0 0 0 0 0 0 0 0 0 ',0,1,32570,483,1490337443,1,60.9388,0,0,0,0,0,0,0,19,0,0,1537,1490169784,'',0,0,0,0,0,0,0,0,2147483647,0,55,0,0,0,100,0,'4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 4294967295 ','0 0 0 0 0 0 49 0 0 0 0 0 48 0 47 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2092 0 0 0 28979 0 0 0 ',0,'0 0 ',3,NULL,NULL,NULL),(6,9,'Sally',10,3,1,10,615,452,101384200,33554434,8,9738.47,-6678.72,0.570352,530,0,0.0507836,'0 0 131072 4 0 0 0 0 0 0 0 0 0 0 0 0 ',0,1,9520,1416,1490202810,0,3.40872,0,0,0,0,0,0,0,3,0,0,3430,1490198629,'',0,0,0,0,0,0,0,0,2147483647,0,209,361,0,0,100,0,'0 0 16777216 3221225472 4096 0 0 0 0 0 0 0 0 0 0 0 0 4096 0 0 0 65544 0 0 0 0 0 0 0 0 0 0 0 0 46662444 524288 120 0 0 0 832 0 0 0 0 0 33554432 0 2 122880 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6256 0 0 0 20838 0 0 0 ',2512,'0 0 ',0,NULL,NULL,NULL),(7,8,'Dantetho',1,4,1,7,1030,1052,16778246,33554438,32,-9460,43.2037,56.9495,0,0,4.67124,'2 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 ',0,1,11346,1012,1490225486,1,1.02641,0,0,0,0,0,0,0,6,0,0,12,0,'',0,2,2,0,1,1,0,0,2147483647,0,157,0,0,0,100,0,'0 0 0 3758096384 3221233800 8 524288 0 0 0 0 0 0 0 0 0 0 16 0 0 0 65536 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16384 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 49 0 60 0 0 0 48 0 47 0 6070 0 0 0 0 0 0 0 0 0 0 0 11475 0 2057 0 0 0 28979 0 0 0 ',0,'0 0 ',3,NULL,NULL,NULL),(8,10,'Danteyo',1,1,1,10,2611,479,16778247,16777218,32,-9467.05,35.3867,56.9663,0,0,1.54766,'2 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 ',0,1,16012,1370,1490336975,1,1165.64,0,0,0,0,0,0,0,4,0,0,12,0,'',0,0,0,0,0,0,0,0,2147483647,0,251,0,0,0,100,0,'0 0 0 1610612736 3221233800 12 0 0 0 0 0 0 0 0 0 0 0 16 0 0 0 65536 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 38 0 60 0 2690 0 2962 0 2691 0 6070 0 2653 0 0 0 0 0 0 0 0 0 0 0 1161 0 2362 0 0 0 0 0 ',0,'0 0 ',7,NULL,NULL,NULL),(9,8,'Dante',4,1,0,1,0,0,67307525,33554432,0,10311.3,832.463,1326.41,1,0,5.69632,'100663296 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 ',0,0,0,0,1490181050,0,0,0,0,0,0,0,0,0,2,0,32,0,0,'',0,0,0,0,0,0,0,0,4294967295,0,50,0,0,0,100,0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 6120 0 0 0 0 0 6121 0 6122 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 0 2362 0 0 0 0 0 ',0,'0 0 ',0,NULL,NULL,NULL),(10,13,'Huntard',2,3,1,10,1352,102,2053,16777220,32,-4838.21,-991.499,459.495,0,0,3.94851,'4194304 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 ',0,1,3181,3136,1490337153,1,294.269,0,0,0,0,0,0,0,2,0,0,1537,1490337906,'',0,0,0,0,0,0,0,0,2147483647,0,178,256,0,0,100,0,'0 4 50331648 3221225472 131072 0 1048576 0 0 50331648 0 0 0 0 0 0 0 0 0 0 0 8519680 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 127 0 0 0 0 0 6126 0 6127 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 37 0 0 0 2504 0 0 0 ',2512,'0 0 ',0,NULL,NULL,NULL),(11,12,'Faewynn',7,1,1,70,0,2137217586,67239940,33554432,1056,-5015.8,-926.638,501.659,0,0,4.15879,'32 0 0 8 0 0 1048576 0 0 0 0 0 0 0 0 0 ',0,1,3329,2930,1490226851,1,0,10000,1490209940,0,0,0,0,0,4,0,0,1537,0,'',0,0,0,0,0,0,0,0,2147483647,0,8534,0,0,0,100,0,'1 0 0 1082130432 262168 10485762 1572880 33554432 0 8 2147483648 0 0 0 0 0 16 16 0 0 525824 8589312 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','30972 0 0 0 30979 0 38 0 30975 0 34546 0 30977 0 34569 0 34441 0 30969 0 0 0 0 0 0 0 0 0 0 0 30902 0 0 0 0 0 0 0 ',0,'0 0 ',0,NULL,NULL,NULL),(15,12,'Dragmyhair',7,9,1,4,0,4611,100663300,33554432,0,-6101.3,395.887,395.541,0,0,3.67488,'32 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 ',0,1,244,3,1490227206,0,0.00138889,0,0,0,0,0,0,0,4,0,0,1,0,'',0,0,0,0,0,0,0,0,2147483647,0,88,272,0,0,100,0,'0 0 0 0 0 0 1048576 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 6097 0 57 0 0 0 1396 0 59 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 2092 0 0 0 0 0 0 0 ',0,'0 0 ',0,NULL,NULL,NULL),(16,16,'Accgonewild',7,9,1,14,12067,13003,100663556,33554432,32,-5364.88,-2967.6,326.78,0,0,4.92151,'160 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 ',0,1,13402,1519,1490249596,1,0.642769,0,0,0,0,0,0,0,4,0,0,38,1490238406,'',0,0,0,0,0,0,0,0,2147483647,0,258,637,0,0,100,0,'1 0 0 1082130432 131080 8388610 2281177088 33554432 4096 50855936 0 0 0 0 0 0 0 16 0 0 1022976 196608 0 0 0 96 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 6097 0 3216 0 0 0 2958 0 59 0 2326 0 10550 0 0 0 0 0 0 0 0 0 3153 0 2218 0 15925 0 0 0 0 0 ',0,'0 0 ',15,NULL,NULL,NULL),(17,12,'Testing',5,1,0,1,0,0,151519491,33554438,0,1711.54,1644.72,124.844,0,0,5.66386,'1024 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 ',0,1,277,277,1490237194,0,0.00173611,0,0,0,0,0,0,0,4,0,0,85,0,'',0,0,0,0,0,0,0,0,2147483647,0,70,0,0,0,100,0,'0 0 0 0 0 0 0 128 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 512 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 6125 0 0 0 0 0 139 0 140 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 0 2362 0 0 0 0 0 ',0,'0 0 ',0,NULL,NULL,NULL),(18,10,'Danteshow',10,2,1,6,2996,1022,134284297,33554432,0,10298.1,-6196.83,26.0818,530,0,4.86838,'0 0 131072 4 0 0 0 0 0 0 0 0 0 0 0 0 ',0,1,2615,581,1490311387,0,0.350781,0,0,0,0,0,0,0,4,0,0,3430,0,'',0,0,0,0,0,0,0,0,2147483647,0,198,259,0,0,100,0,'0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4194304 0 0 0 0 0 0 0 0 0 0 0 0 0 0 49152 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ','0 0 0 0 0 0 24143 0 20994 0 21015 0 24145 0 20997 0 0 0 20999 0 0 0 0 0 0 0 0 0 20991 0 20835 0 0 0 0 0 0 0 ',0,'0 0 ',7,NULL,NULL,NULL);
/*!40000 ALTER TABLE `characters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `corpse`
--

DROP TABLE IF EXISTS `corpse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `corpse` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `player` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `position_x` float NOT NULL DEFAULT '0',
  `position_y` float NOT NULL DEFAULT '0',
  `position_z` float NOT NULL DEFAULT '0',
  `orientation` float NOT NULL DEFAULT '0',
  `map` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Map Identifier',
  `time` bigint(20) unsigned NOT NULL DEFAULT '0',
  `corpse_type` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `instance` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`),
  KEY `idx_type` (`corpse_type`),
  KEY `instance` (`instance`),
  KEY `Idx_player` (`player`),
  KEY `Idx_time` (`time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Death System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `corpse`
--

LOCK TABLES `corpse` WRITE;
/*!40000 ALTER TABLE `corpse` DISABLE KEYS */;
/*!40000 ALTER TABLE `corpse` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `creature_respawn`
--

DROP TABLE IF EXISTS `creature_respawn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `creature_respawn` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `respawntime` bigint(20) unsigned NOT NULL DEFAULT '0',
  `instance` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Grid Loading System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `creature_respawn`
--

LOCK TABLES `creature_respawn` WRITE;
/*!40000 ALTER TABLE `creature_respawn` DISABLE KEYS */;
INSERT INTO `creature_respawn` VALUES (101037,1490337079,0);
/*!40000 ALTER TABLE `creature_respawn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_event_status`
--

DROP TABLE IF EXISTS `game_event_status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `game_event_status` (
  `event` smallint(6) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`event`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Game event system';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_event_status`
--

LOCK TABLES `game_event_status` WRITE;
/*!40000 ALTER TABLE `game_event_status` DISABLE KEYS */;
INSERT INTO `game_event_status` VALUES (16),(21),(27),(32),(47),(61),(62);
/*!40000 ALTER TABLE `game_event_status` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gameobject_respawn`
--

DROP TABLE IF EXISTS `gameobject_respawn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gameobject_respawn` (
  `guid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `respawntime` bigint(20) unsigned NOT NULL DEFAULT '0',
  `instance` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Grid Loading System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gameobject_respawn`
--

LOCK TABLES `gameobject_respawn` WRITE;
/*!40000 ALTER TABLE `gameobject_respawn` DISABLE KEYS */;
/*!40000 ALTER TABLE `gameobject_respawn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_instance`
--

DROP TABLE IF EXISTS `group_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_instance` (
  `leaderGuid` int(11) unsigned NOT NULL DEFAULT '0',
  `instance` int(11) unsigned NOT NULL DEFAULT '0',
  `permanent` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`leaderGuid`,`instance`),
  KEY `instance` (`instance`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_instance`
--

LOCK TABLES `group_instance` WRITE;
/*!40000 ALTER TABLE `group_instance` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_member`
--

DROP TABLE IF EXISTS `group_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_member` (
  `groupId` int(11) unsigned NOT NULL,
  `memberGuid` int(11) unsigned NOT NULL,
  `assistant` tinyint(1) unsigned NOT NULL,
  `subgroup` smallint(6) unsigned NOT NULL,
  PRIMARY KEY (`groupId`,`memberGuid`),
  KEY `Idx_memberGuid` (`memberGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Groups';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_member`
--

LOCK TABLES `group_member` WRITE;
/*!40000 ALTER TABLE `group_member` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `groups`
--

DROP TABLE IF EXISTS `groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `groups` (
  `groupId` int(11) unsigned NOT NULL,
  `leaderGuid` int(11) unsigned NOT NULL,
  `mainTank` int(11) unsigned NOT NULL,
  `mainAssistant` int(11) unsigned NOT NULL,
  `lootMethod` tinyint(4) unsigned NOT NULL,
  `looterGuid` int(11) unsigned NOT NULL,
  `lootThreshold` tinyint(4) unsigned NOT NULL,
  `icon1` int(11) unsigned NOT NULL,
  `icon2` int(11) unsigned NOT NULL,
  `icon3` int(11) unsigned NOT NULL,
  `icon4` int(11) unsigned NOT NULL,
  `icon5` int(11) unsigned NOT NULL,
  `icon6` int(11) unsigned NOT NULL,
  `icon7` int(11) unsigned NOT NULL,
  `icon8` int(11) unsigned NOT NULL,
  `isRaid` tinyint(1) unsigned NOT NULL,
  `difficulty` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`groupId`),
  UNIQUE KEY `leaderGuid` (`leaderGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Groups';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `groups`
--

LOCK TABLES `groups` WRITE;
/*!40000 ALTER TABLE `groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild`
--

DROP TABLE IF EXISTS `guild`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild` (
  `guildid` int(6) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `leaderguid` int(6) unsigned NOT NULL DEFAULT '0',
  `EmblemStyle` int(5) NOT NULL DEFAULT '0',
  `EmblemColor` int(5) NOT NULL DEFAULT '0',
  `BorderStyle` int(5) NOT NULL DEFAULT '0',
  `BorderColor` int(5) NOT NULL DEFAULT '0',
  `BackgroundColor` int(5) NOT NULL DEFAULT '0',
  `info` varchar(500) NOT NULL DEFAULT '',
  `motd` varchar(128) NOT NULL DEFAULT '',
  `createdate` bigint(20) unsigned NOT NULL DEFAULT '0',
  `BankMoney` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Guild System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild`
--

LOCK TABLES `guild` WRITE;
/*!40000 ALTER TABLE `guild` DISABLE KEYS */;
INSERT INTO `guild` VALUES (1,'The Devs',3,0,0,0,0,0,'','No message set.',1490168594,0),(2,'Not Chowsky',6,0,0,0,0,0,'','No message set.',1490176272,0);
/*!40000 ALTER TABLE `guild` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_bank_eventlog`
--

DROP TABLE IF EXISTS `guild_bank_eventlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_bank_eventlog` (
  `guildid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Guild Identificator',
  `LogGuid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Log record identificator - auxiliary column',
  `TabId` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Guild bank TabId',
  `EventType` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT 'Event type',
  `PlayerGuid` int(11) unsigned NOT NULL DEFAULT '0',
  `ItemOrMoney` int(11) unsigned NOT NULL DEFAULT '0',
  `ItemStackCount` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `DestTabId` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'Destination Tab Id',
  `TimeStamp` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Event UNIX time',
  PRIMARY KEY (`guildid`,`LogGuid`,`TabId`),
  KEY `Idx_PlayerGuid` (`PlayerGuid`),
  KEY `Idx_LogGuid` (`LogGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_bank_eventlog`
--

LOCK TABLES `guild_bank_eventlog` WRITE;
/*!40000 ALTER TABLE `guild_bank_eventlog` DISABLE KEYS */;
INSERT INTO `guild_bank_eventlog` VALUES (2,1,100,6,6,0,0,0,1490177095);
/*!40000 ALTER TABLE `guild_bank_eventlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_bank_item`
--

DROP TABLE IF EXISTS `guild_bank_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_bank_item` (
  `guildid` int(11) unsigned NOT NULL DEFAULT '0',
  `TabId` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `SlotId` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `item_guid` int(11) unsigned NOT NULL DEFAULT '0',
  `item_entry` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`,`TabId`,`SlotId`),
  KEY `Idx_item_guid` (`item_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_bank_item`
--

LOCK TABLES `guild_bank_item` WRITE;
/*!40000 ALTER TABLE `guild_bank_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_bank_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_bank_right`
--

DROP TABLE IF EXISTS `guild_bank_right`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_bank_right` (
  `guildid` int(11) unsigned NOT NULL DEFAULT '0',
  `TabId` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `rid` int(11) unsigned NOT NULL DEFAULT '0',
  `gbright` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `SlotPerDay` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`,`TabId`,`rid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_bank_right`
--

LOCK TABLES `guild_bank_right` WRITE;
/*!40000 ALTER TABLE `guild_bank_right` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_bank_right` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_bank_tab`
--

DROP TABLE IF EXISTS `guild_bank_tab`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_bank_tab` (
  `guildid` int(11) unsigned NOT NULL DEFAULT '0',
  `TabId` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `TabName` varchar(100) NOT NULL DEFAULT '',
  `TabIcon` varchar(100) NOT NULL DEFAULT '',
  `TabText` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`guildid`,`TabId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_bank_tab`
--

LOCK TABLES `guild_bank_tab` WRITE;
/*!40000 ALTER TABLE `guild_bank_tab` DISABLE KEYS */;
/*!40000 ALTER TABLE `guild_bank_tab` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_eventlog`
--

DROP TABLE IF EXISTS `guild_eventlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_eventlog` (
  `guildid` int(11) unsigned NOT NULL COMMENT 'Guild Identificator',
  `LogGuid` int(11) unsigned NOT NULL COMMENT 'Log record identificator - auxiliary column',
  `EventType` tinyint(1) unsigned NOT NULL COMMENT 'Event type',
  `PlayerGuid1` int(11) unsigned NOT NULL COMMENT 'Player 1',
  `PlayerGuid2` int(11) unsigned NOT NULL COMMENT 'Player 2',
  `NewRank` tinyint(2) unsigned NOT NULL COMMENT 'New rank(in case promotion/demotion)',
  `TimeStamp` bigint(20) unsigned NOT NULL COMMENT 'Event UNIX time',
  PRIMARY KEY (`guildid`,`LogGuid`),
  KEY `Idx_PlayerGuid1` (`PlayerGuid1`),
  KEY `Idx_PlayerGuid2` (`PlayerGuid2`),
  KEY `Idx_LogGuid` (`LogGuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Guild Eventlog';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_eventlog`
--

LOCK TABLES `guild_eventlog` WRITE;
/*!40000 ALTER TABLE `guild_eventlog` DISABLE KEYS */;
INSERT INTO `guild_eventlog` VALUES (1,1,1,3,1,0,1490168602),(1,2,2,1,0,0,1490168604),(1,3,3,3,1,3,1490168607),(1,4,3,3,1,2,1490168608),(1,5,3,3,1,1,1490168609);
/*!40000 ALTER TABLE `guild_eventlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_member`
--

DROP TABLE IF EXISTS `guild_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_member` (
  `guildid` int(6) unsigned NOT NULL DEFAULT '0',
  `guid` int(11) unsigned NOT NULL DEFAULT '0',
  `rank` tinyint(2) unsigned NOT NULL DEFAULT '0',
  `pnote` varchar(31) NOT NULL DEFAULT '',
  `offnote` varchar(31) NOT NULL DEFAULT '',
  `BankResetTimeMoney` int(11) unsigned NOT NULL DEFAULT '0',
  `BankRemMoney` int(11) unsigned NOT NULL DEFAULT '0',
  `BankResetTimeTab0` int(11) unsigned NOT NULL DEFAULT '0',
  `BankRemSlotsTab0` int(11) unsigned NOT NULL DEFAULT '0',
  `BankResetTimeTab1` int(11) unsigned NOT NULL DEFAULT '0',
  `BankRemSlotsTab1` int(11) unsigned NOT NULL DEFAULT '0',
  `BankResetTimeTab2` int(11) unsigned NOT NULL DEFAULT '0',
  `BankRemSlotsTab2` int(11) unsigned NOT NULL DEFAULT '0',
  `BankResetTimeTab3` int(11) unsigned NOT NULL DEFAULT '0',
  `BankRemSlotsTab3` int(11) unsigned NOT NULL DEFAULT '0',
  `BankResetTimeTab4` int(11) unsigned NOT NULL DEFAULT '0',
  `BankRemSlotsTab4` int(11) unsigned NOT NULL DEFAULT '0',
  `BankResetTimeTab5` int(11) unsigned NOT NULL DEFAULT '0',
  `BankRemSlotsTab5` int(11) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `guid_key` (`guid`),
  KEY `guildid_rank_key` (`guildid`,`rank`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Guild System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_member`
--

LOCK TABLES `guild_member` WRITE;
/*!40000 ALTER TABLE `guild_member` DISABLE KEYS */;
INSERT INTO `guild_member` VALUES (1,1,1,'','',24836143,0,0,0,0,0,0,0,0,0,0,0,0,0),(1,3,0,'','',0,0,0,0,0,0,0,0,0,0,0,0,0,0),(2,6,0,'','',0,0,0,0,0,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `guild_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guild_rank`
--

DROP TABLE IF EXISTS `guild_rank`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `guild_rank` (
  `guildid` int(6) unsigned NOT NULL DEFAULT '0',
  `rid` int(11) unsigned NOT NULL,
  `rname` varchar(255) NOT NULL DEFAULT '',
  `rights` int(3) unsigned NOT NULL DEFAULT '0',
  `BankMoneyPerDay` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guildid`,`rid`),
  KEY `Idx_rid` (`rid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Guild System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guild_rank`
--

LOCK TABLES `guild_rank` WRITE;
/*!40000 ALTER TABLE `guild_rank` DISABLE KEYS */;
INSERT INTO `guild_rank` VALUES (1,0,'Guild Master',913919,4294967295),(1,1,'Officer',913919,0),(1,2,'Veteran',67,0),(1,3,'Member',67,0),(1,4,'Initiate',67,0),(2,0,'Guild Master',913919,4294967295),(2,1,'Officer',913919,0),(2,2,'Veteran',67,0),(2,3,'Member',67,0),(2,4,'Initiate',67,0);
/*!40000 ALTER TABLE `guild_rank` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance`
--

DROP TABLE IF EXISTS `instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `map` int(11) unsigned NOT NULL DEFAULT '0',
  `resettime` bigint(40) unsigned NOT NULL DEFAULT '0',
  `difficulty` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `data` longtext,
  PRIMARY KEY (`id`),
  KEY `map` (`map`),
  KEY `resettime` (`resettime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance`
--

LOCK TABLES `instance` WRITE;
/*!40000 ALTER TABLE `instance` DISABLE KEYS */;
/*!40000 ALTER TABLE `instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `instance_reset`
--

DROP TABLE IF EXISTS `instance_reset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `instance_reset` (
  `mapid` int(11) unsigned NOT NULL DEFAULT '0',
  `resettime` bigint(40) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`mapid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `instance_reset`
--

LOCK TABLES `instance_reset` WRITE;
/*!40000 ALTER TABLE `instance_reset` DISABLE KEYS */;
INSERT INTO `instance_reset` VALUES (249,1490587200),(269,1490414400),(309,1490414400),(409,1490760000),(469,1490760000),(509,1490414400),(531,1490760000),(532,1490760000),(533,1490760000),(534,1490760000),(540,1490414400),(542,1490414400),(543,1490414400),(544,1490760000),(545,1490414400),(546,1490414400),(547,1490414400),(548,1490760000),(550,1490760000),(552,1490414400),(553,1490414400),(554,1490414400),(555,1490414400),(556,1490414400),(557,1490414400),(558,1490414400),(560,1490414400),(564,1490760000),(565,1490760000),(568,1490414400),(580,1490760000),(585,1490414400);
/*!40000 ALTER TABLE `instance_reset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_instance`
--

DROP TABLE IF EXISTS `item_instance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_instance` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0',
  `owner_guid` int(11) unsigned NOT NULL DEFAULT '0',
  `data` longtext,
  PRIMARY KEY (`guid`),
  KEY `idx_owner_guid` (`owner_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Item System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_instance`
--

LOCK TABLES `item_instance` WRITE;
/*!40000 ALTER TABLE `item_instance` DISABLE KEYS */;
INSERT INTO `item_instance` VALUES (2,1,'2 1073741824 3 56 1065353216 0 1 0 1 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 '),(4,1,'4 1073741824 3 1395 1065353216 0 1 0 1 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 '),(6,1,'6 1073741824 3 55 1065353216 0 1 0 1 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(8,1,'8 1073741824 3 35 1065353216 0 1 0 1 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 '),(10,1,'10 1073741824 3 6096 1065353216 0 1 0 1 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(12,1,'12 1073741824 3 2070 1065353216 0 1 0 1 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(14,1,'14 1073741824 3 159 1065353216 0 1 0 1 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(16,1,'16 1073741824 3 6948 1065353216 0 1 0 1 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(17,1,'17 1073741824 3 7073 1065353216 0 1 0 1 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(33,3,'33 1073741824 3 49 1065353216 0 3 0 3 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(35,3,'35 1073741824 3 47 1065353216 0 3 0 3 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(37,3,'37 1073741824 3 48 1065353216 0 3 0 3 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 '),(39,3,'39 1073741824 3 28979 1065353216 0 3 0 3 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 199 200 '),(41,3,'41 1073741824 3 2092 1065353216 0 3 0 3 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 '),(43,3,'43 1073741824 3 2070 1065353216 0 3 0 3 0 0 0 0 0 3 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(45,3,'45 1073741824 3 6948 1065353216 0 3 0 3 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(63,3,'63 1073741824 3 750 1065353216 0 3 0 3 0 0 0 0 0 6 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(66,3,'66 1073741824 7 828 1065353216 0 3 0 3 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(90,6,'90 1073741824 3 20901 1065353216 0 6 0 178 1073741824 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(92,6,'92 1073741824 3 20899 1065353216 0 6 0 178 1073741824 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 '),(94,6,'94 1073741824 3 20900 1065353216 0 6 0 178 1073741824 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 '),(96,6,'96 1073741824 3 159 1065353216 0 6 0 6 0 0 0 0 0 11 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(98,6,'98 1073741824 3 20982 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 '),(100,6,'100 1073741824 3 6948 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(102,6,'102 1073741824 7 2101 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 415 1073741824 207 1073741824 208 1073741824 209 1073741824 210 1073741824 211 1073741824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(112,3,'112 1073741824 7 17966 1065353216 0 3 0 3 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(136,6,'136 1073741824 7 20474 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 414 1073741824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(172,6,'172 1073741824 7 5571 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(178,6,'178 1073741824 7 805 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 413 1073741824 94 1073741824 92 1073741824 212 1073741824 204 1073741824 90 1073741824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(182,7,'182 1073741824 3 49 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(184,7,'184 1073741824 3 47 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(186,7,'186 1073741824 3 48 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 '),(188,7,'188 1073741824 3 28979 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 200 200 '),(192,7,'192 1073741824 3 2070 1065353216 0 7 0 7 0 0 0 0 0 6 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(194,7,'194 1073741824 3 6948 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(204,6,'204 1073741824 3 20993 1065353216 0 6 0 178 1073741824 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 '),(205,6,'205 1073741824 3 21000 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 '),(207,6,'207 1073741824 3 2512 1065353216 0 6 0 102 1073741824 0 0 0 0 200 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(208,6,'208 1073741824 3 2512 1065353216 0 6 0 102 1073741824 0 0 0 0 200 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(209,6,'209 1073741824 3 2512 1065353216 0 6 0 102 1073741824 0 0 0 0 200 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(210,6,'210 1073741824 3 2512 1065353216 0 6 0 102 1073741824 0 0 0 0 200 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(211,6,'211 1073741824 3 2512 1065353216 0 6 0 102 1073741824 0 0 0 0 200 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(212,6,'212 1073741824 3 20996 1065353216 0 6 0 178 1073741824 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 '),(281,7,'281 1073741824 3 6070 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 '),(282,6,'282 1073741824 3 20838 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 '),(287,6,'287 1073741824 3 20813 1065353216 0 6 0 6 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(303,7,'303 1073741824 3 2057 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 '),(380,7,'380 1073741824 3 60 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 '),(382,7,'382 1073741824 3 11475 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(386,6,'386 1073741824 3 4540 1065353216 0 6 0 6 0 0 0 0 0 8 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(411,7,'411 1073741824 3 4656 1065353216 0 7 0 7 0 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(413,6,'413 1073741824 3 27552 1065353216 0 6 0 178 1073741824 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 '),(415,6,'415 1073741824 3 2512 1065353216 0 6 0 102 1073741824 0 0 0 0 200 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(416,6,'416 1073741824 3 2512 1065353216 0 6 0 6 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(419,7,'419 1073741824 3 2901 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(421,8,'421 1073741824 3 38 1065353216 0 8 0 8 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(429,8,'429 1073741824 3 2362 1065353216 0 8 0 8 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 '),(433,8,'433 1073741824 3 6948 1065353216 0 8 0 1181 1073741824 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(435,9,'435 1073741824 3 25 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 '),(437,9,'437 1073741824 3 6120 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(439,9,'439 1073741824 3 6121 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 '),(441,9,'441 1073741824 3 6122 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(443,9,'443 1073741824 3 2362 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 '),(445,9,'445 1073741824 3 117 1065353216 0 9 0 9 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(447,9,'447 1073741824 3 6948 1065353216 0 9 0 9 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(448,6,'448 1073741824 3 6256 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 '),(450,6,'450 1073741824 3 6529 1065353216 0 6 0 6 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(451,6,'451 1073741824 3 769 1065353216 0 6 0 6 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(452,6,'452 1073741824 3 3171 1065353216 0 6 0 6 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(453,1,'453 1073741824 3 24490 1065353216 0 1 0 1 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(454,1,'454 1073741824 3 30673 1065353216 0 1 0 1 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 '),(455,1,'455 1073741824 3 28530 1065353216 0 1 0 1 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(457,10,'457 1073741824 3 127 1065353216 0 10 0 10 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(459,10,'459 1073741824 3 6126 1065353216 0 10 0 10 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 15 25 '),(461,10,'461 1073741824 3 6127 1065353216 0 10 0 10 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(463,10,'463 1073741824 3 159 1065353216 0 10 0 10 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(465,10,'465 1073741824 3 37 1065353216 0 10 0 10 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 10 20 '),(467,10,'467 1073741824 3 6948 1065353216 0 10 0 10 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(469,10,'469 1073741824 7 2101 1065353216 0 10 0 10 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 475 1073741824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(471,10,'471 1073741824 3 2504 1065353216 0 10 0 10 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 10 20 '),(473,10,'473 1073741824 3 117 1065353216 0 10 0 10 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(475,10,'475 1073741824 3 2512 1065353216 0 10 0 469 1073741824 0 0 0 0 155 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(477,11,'477 1073741824 3 38 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(479,11,'479 1073741824 3 39 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 '),(481,11,'481 1073741824 3 40 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(483,11,'483 1073741824 3 25 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 '),(485,11,'485 1073741824 3 2362 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 '),(489,11,'489 1073741824 3 6948 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(490,10,'490 1073741824 3 15917 1065353216 0 10 0 10 0 0 0 0 0 1 0 3 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(492,11,'492 1073741824 3 30979 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 99 100 '),(493,11,'493 1073741824 3 34569 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 75 75 '),(494,11,'494 1073741824 3 34441 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 '),(496,11,'496 1073741824 3 30969 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 54 55 '),(497,11,'497 1073741824 3 30972 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 100 100 '),(498,11,'498 1073741824 3 30975 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 164 165 '),(499,11,'499 1073741824 3 34546 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 '),(500,11,'500 1073741824 3 30977 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 '),(501,11,'501 1073741824 3 30902 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 120 120 '),(502,11,'502 1073741824 3 2771 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(503,11,'503 1073741824 3 2589 1065353216 0 11 0 11 0 0 0 0 0 3 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(504,11,'504 1073741824 3 2592 1065353216 0 11 0 11 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(505,11,'505 1073741824 3 858 1065353216 0 11 0 11 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(506,11,'506 1073741824 3 2775 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(521,11,'521 1073741824 3 18774 1065353216 0 11 0 11 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(523,7,'523 1073741824 3 769 1065353216 0 7 0 7 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(530,7,'530 1073741824 3 2770 1065353216 0 7 0 7 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(532,7,'532 1073741824 3 2835 1065353216 0 7 0 7 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(572,7,'572 1073741824 3 118 1065353216 0 7 0 7 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(579,7,'579 1073741824 3 957 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(580,7,'580 1073741824 3 1251 1065353216 0 7 0 7 0 0 0 0 0 7 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(581,7,'581 1073741824 3 2672 1065353216 0 7 0 7 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(641,15,'641 1073741824 3 57 1065353216 0 15 0 15 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 35 35 '),(643,15,'643 1073741824 3 6097 1065353216 0 15 0 15 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(645,15,'645 1073741824 3 1396 1065353216 0 15 0 15 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 '),(647,15,'647 1073741824 3 59 1065353216 0 15 0 15 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(649,15,'649 1073741824 3 2092 1065353216 0 15 0 15 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 '),(651,15,'651 1073741824 3 159 1065353216 0 15 0 15 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(653,15,'653 1073741824 3 4604 1065353216 0 15 0 15 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(655,15,'655 1073741824 3 6948 1065353216 0 15 0 15 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(656,15,'656 1073741824 3 2187 1065353216 0 15 0 15 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(657,15,'657 1073741824 3 750 1065353216 0 15 0 15 0 0 0 0 0 2 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(658,15,'658 1073741824 3 4865 1065353216 0 15 0 15 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(661,15,'661 1073741824 3 7073 1065353216 0 15 0 15 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(662,15,'662 1073741824 3 7074 1065353216 0 15 0 15 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(666,16,'666 1073741824 3 6097 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(670,16,'670 1073741824 3 59 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(678,16,'678 1073741824 3 6948 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(708,16,'708 1073741824 7 5571 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 1195 1073741824 1155 1073741824 1156 1073741824 1196 1073741824 0 0 1220 1073741824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(802,17,'802 1073741824 3 6125 1065353216 0 17 0 17 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(804,17,'804 1073741824 3 139 1065353216 0 17 0 17 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 '),(806,17,'806 1073741824 3 140 1065353216 0 17 0 17 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(808,17,'808 1073741824 3 25 1065353216 0 17 0 17 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 '),(810,17,'810 1073741824 3 2362 1065353216 0 17 0 17 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 '),(812,17,'812 1073741824 3 4604 1065353216 0 17 0 17 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(814,17,'814 1073741824 3 6948 1065353216 0 17 0 17 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(825,16,'825 1073741824 3 2894 1065353216 0 16 0 16 0 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(851,8,'851 1073741824 3 6070 1065353216 0 8 0 8 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 '),(862,16,'862 1073741824 3 3153 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(876,8,'876 1073741824 3 2962 1065353216 0 8 0 8 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 '),(890,16,'890 1073741824 3 2326 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 15 16 '),(897,8,'897 1073741824 3 1161 1065353216 0 8 0 8 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 '),(909,16,'909 1073741824 3 2958 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 34 35 '),(918,8,'918 1073741824 3 2690 1065353216 0 8 0 8 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 '),(920,16,'920 1073741824 3 10550 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 '),(922,16,'922 1073741824 3 4541 1065353216 0 16 0 16 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(926,16,'926 1073741824 3 1179 1065353216 0 16 0 16 0 0 0 0 0 16 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(930,16,'930 1073741824 3 3216 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 43 45 '),(937,8,'937 1073741824 7 5572 1065353216 0 8 0 8 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 1136 1073741824 1109 1073741824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(943,8,'943 1073741824 3 60 1065353216 0 8 0 8 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 '),(944,8,'944 1073741824 3 2691 1065353216 0 8 0 8 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 '),(951,8,'951 1073741824 3 7005 1065353216 0 8 0 8 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1008,8,'1008 1073741824 3 2653 1065353216 0 8 0 8 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 '),(1036,16,'1036 1073741824 3 15925 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1103,16,'1103 1073741824 3 769 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1109,8,'1109 1073741824 3 1434 1065353216 0 8 0 937 1073741824 0 0 0 0 5 0 4294967295 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1111,8,'1111 1073741824 3 1251 1065353216 0 8 0 1181 1073741824 0 0 0 0 20 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1119,16,'1119 1073741824 3 3151 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 65 65 '),(1136,8,'1136 1073741824 3 1191 1065353216 0 8 0 937 1073741824 0 0 0 0 1 0 4294967286 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1137,16,'1137 1073741824 3 2218 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 28 30 '),(1138,8,'1138 1073741824 3 118 1065353216 0 8 0 1181 1073741824 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1140,8,'1140 1073741824 3 2454 1065353216 0 8 0 1181 1073741824 0 0 0 0 1 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1143,16,'1143 1073741824 3 2589 1065353216 0 16 0 16 0 0 0 0 0 20 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1145,8,'1145 1073741824 3 2806 1065353216 0 8 0 8 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1146,10,'1146 1073741824 3 2589 1065353216 0 10 0 10 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1155,16,'1155 1073741824 3 858 1065353216 0 16 0 708 1073741824 0 0 0 0 5 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1156,16,'1156 1073741824 3 1705 1065353216 0 16 0 708 1073741824 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1163,16,'1163 1073741824 3 414 1065353216 0 16 0 16 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1170,16,'1170 1073741824 3 1503 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 '),(1172,8,'1172 1073741824 3 1251 1065353216 0 8 0 1181 1073741824 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1174,16,'1174 1073741824 3 2287 1065353216 0 16 0 16 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1175,16,'1175 1073741824 3 1511 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 45 45 '),(1177,16,'1177 1073741824 3 818 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1179,10,'1179 1073741824 3 2268 1065353216 0 10 0 10 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 40 40 '),(1180,10,'1180 1073741824 3 1501 1065353216 0 10 0 10 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 50 50 '),(1181,8,'1181 1073741824 7 4496 1065353216 0 8 0 8 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 433 1073741824 1111 1073741824 1138 1073741824 1140 1073741824 0 0 1172 1073741824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1182,8,'1182 1073741824 7 4496 1065353216 0 8 0 8 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1183,8,'1183 1073741824 7 4496 1065353216 0 8 0 8 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1189,16,'1189 1073741824 3 2589 1065353216 0 16 0 16 0 0 0 0 0 14 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1192,16,'1192 1073741824 7 5573 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 8 0 1221 1073741824 1222 1073741824 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1194,16,'1194 1073741824 3 9811 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 72 0 0 70 0 0 0 0 0 0 1184 0 30 30 '),(1195,16,'1195 1073741824 3 2318 1065353216 0 16 0 708 1073741824 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1196,16,'1196 1073741824 3 6555 1065353216 0 16 0 708 1073741824 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1200,16,'1200 1073741824 3 5512 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1204,18,'1204 1073741824 3 24143 1065353216 0 18 0 18 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1206,18,'1206 1073741824 3 24145 1065353216 0 18 0 18 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 '),(1212,18,'1212 1073741824 3 20857 1065353216 0 18 0 18 0 0 0 0 0 4 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1214,18,'1214 1073741824 3 159 1065353216 0 18 0 18 0 0 0 0 0 2 0 4294967295 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1216,18,'1216 1073741824 3 6948 1065353216 0 18 0 18 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1220,16,'1220 1073741824 3 6265 1065353216 0 16 0 708 1073741824 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1221,16,'1221 1073741824 3 9758 1065353216 0 16 0 1192 1073741824 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 20 20 '),(1222,16,'1222 1073741824 3 6265 1065353216 0 16 0 1192 1073741824 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1236,18,'1236 1073741824 3 20997 1065353216 0 18 0 18 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 25 25 '),(1237,18,'1237 1073741824 7 20474 1065353216 0 18 0 18 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 4 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1239,16,'1239 1073741824 3 16310 1065353216 0 16 0 16 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1289,18,'1289 1073741824 3 20994 1065353216 0 18 0 18 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 55 55 '),(1290,18,'1290 1073741824 3 20991 1065353216 0 18 0 18 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1291,18,'1291 1073741824 3 20999 1065353216 0 18 0 18 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 18 18 '),(1353,18,'1353 1073741824 7 5572 1065353216 0 18 0 18 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 6 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1378,18,'1378 1073741824 3 20835 1065353216 0 18 0 18 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 30 30 '),(1380,18,'1380 1073741824 3 20847 1065353216 0 18 0 18 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1381,18,'1381 1073741824 3 20848 1065353216 0 18 0 18 0 0 0 0 0 10 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1387,18,'1387 1073741824 3 20483 1065353216 0 18 0 18 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1390,18,'1390 1073741824 3 20847 1065353216 0 18 0 18 0 0 0 0 0 8 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1395,18,'1395 1073741824 3 20848 1065353216 0 18 0 18 0 0 0 0 0 5 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1400,18,'1400 1073741824 3 21015 1065353216 0 18 0 18 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 16 16 '),(1403,18,'1403 1073741824 3 20799 1065353216 0 18 0 18 0 0 0 0 0 1 0 0 0 0 0 0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 '),(1404,18,'1404 1073741824 3 20813 1065353216 0 18 0 18 0 0 0 0 0 2 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 ');
/*!40000 ALTER TABLE `item_instance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_loot`
--

DROP TABLE IF EXISTS `item_loot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_loot` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0',
  `owner_guid` int(11) unsigned NOT NULL DEFAULT '0',
  `itemid` int(11) unsigned NOT NULL DEFAULT '0',
  `amount` int(11) unsigned NOT NULL DEFAULT '0',
  `suffix` int(11) unsigned NOT NULL DEFAULT '0',
  `property` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`itemid`),
  KEY `idx_owner_guid` (`owner_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Item System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_loot`
--

LOCK TABLES `item_loot` WRITE;
/*!40000 ALTER TABLE `item_loot` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_loot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `item_text`
--

DROP TABLE IF EXISTS `item_text`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `item_text` (
  `id` int(11) unsigned NOT NULL DEFAULT '0',
  `text` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Item System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `item_text`
--

LOCK TABLES `item_text` WRITE;
/*!40000 ALTER TABLE `item_text` DISABLE KEYS */;
/*!40000 ALTER TABLE `item_text` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mail`
--

DROP TABLE IF EXISTS `mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail` (
  `id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Identifier',
  `messageType` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `stationery` tinyint(3) NOT NULL DEFAULT '41',
  `mailTemplateId` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sender` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `receiver` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  `subject` longtext,
  `itemTextId` int(11) unsigned NOT NULL DEFAULT '0',
  `has_items` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `expire_time` bigint(40) unsigned NOT NULL DEFAULT '0',
  `deliver_time` bigint(40) unsigned NOT NULL DEFAULT '0',
  `money` int(11) unsigned NOT NULL DEFAULT '0',
  `cod` int(11) unsigned NOT NULL DEFAULT '0',
  `checked` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_receiver` (`receiver`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Mail System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail`
--

LOCK TABLES `mail` WRITE;
/*!40000 ALTER TABLE `mail` DISABLE KEYS */;
INSERT INTO `mail` VALUES (1,3,41,224,4732,1,'',0,1,1492759790,1490167790,0,0,1),(2,2,62,0,1,1,'7073:0:3',0,1,1492900286,1490308286,0,0,4);
/*!40000 ALTER TABLE `mail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mail_items`
--

DROP TABLE IF EXISTS `mail_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mail_items` (
  `mail_id` int(11) NOT NULL DEFAULT '0',
  `item_guid` int(11) NOT NULL DEFAULT '0',
  `item_template` int(11) NOT NULL DEFAULT '0',
  `receiver` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Character Global Unique Identifier',
  PRIMARY KEY (`mail_id`,`item_guid`),
  KEY `idx_receiver` (`receiver`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mail_items`
--

LOCK TABLES `mail_items` WRITE;
/*!40000 ALTER TABLE `mail_items` DISABLE KEYS */;
INSERT INTO `mail_items` VALUES (2,17,7073,1);
/*!40000 ALTER TABLE `mail_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pet_aura`
--

DROP TABLE IF EXISTS `pet_aura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pet_aura` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `caster_guid` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT 'Full Global Unique Identifier',
  `item_guid` int(11) unsigned NOT NULL DEFAULT '0',
  `spell` int(11) unsigned NOT NULL DEFAULT '0',
  `stackcount` int(11) unsigned NOT NULL DEFAULT '1',
  `remaincharges` int(11) unsigned NOT NULL DEFAULT '0',
  `basepoints0` int(11) NOT NULL DEFAULT '0',
  `basepoints1` int(11) NOT NULL DEFAULT '0',
  `basepoints2` int(11) NOT NULL DEFAULT '0',
  `periodictime0` int(11) unsigned NOT NULL DEFAULT '0',
  `periodictime1` int(11) unsigned NOT NULL DEFAULT '0',
  `periodictime2` int(11) unsigned NOT NULL DEFAULT '0',
  `maxduration` int(11) NOT NULL DEFAULT '0',
  `remaintime` int(11) NOT NULL DEFAULT '0',
  `effIndexMask` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`caster_guid`,`item_guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Pet System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pet_aura`
--

LOCK TABLES `pet_aura` WRITE;
/*!40000 ALTER TABLE `pet_aura` DISABLE KEYS */;
/*!40000 ALTER TABLE `pet_aura` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pet_spell`
--

DROP TABLE IF EXISTS `pet_spell`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pet_spell` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier',
  `spell` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `active` int(11) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Pet System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pet_spell`
--

LOCK TABLES `pet_spell` WRITE;
/*!40000 ALTER TABLE `pet_spell` DISABLE KEYS */;
INSERT INTO `pet_spell` VALUES (8,6307,193),(8,7799,193),(14,3716,193);
/*!40000 ALTER TABLE `pet_spell` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pet_spell_cooldown`
--

DROP TABLE IF EXISTS `pet_spell_cooldown`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pet_spell_cooldown` (
  `guid` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Global Unique Identifier, Low part',
  `spell` int(11) unsigned NOT NULL DEFAULT '0' COMMENT 'Spell Identifier',
  `time` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`guid`,`spell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pet_spell_cooldown`
--

LOCK TABLES `pet_spell_cooldown` WRITE;
/*!40000 ALTER TABLE `pet_spell_cooldown` DISABLE KEYS */;
/*!40000 ALTER TABLE `pet_spell_cooldown` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `petition`
--

DROP TABLE IF EXISTS `petition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `petition` (
  `ownerguid` int(10) unsigned NOT NULL,
  `petitionguid` int(10) unsigned DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `type` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ownerguid`,`type`),
  UNIQUE KEY `index_ownerguid_petitionguid` (`ownerguid`,`petitionguid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Guild System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `petition`
--

LOCK TABLES `petition` WRITE;
/*!40000 ALTER TABLE `petition` DISABLE KEYS */;
/*!40000 ALTER TABLE `petition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `petition_sign`
--

DROP TABLE IF EXISTS `petition_sign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `petition_sign` (
  `ownerguid` int(10) unsigned NOT NULL,
  `petitionguid` int(11) unsigned NOT NULL DEFAULT '0',
  `playerguid` int(11) unsigned NOT NULL DEFAULT '0',
  `player_account` int(11) unsigned NOT NULL DEFAULT '0',
  `type` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`petitionguid`,`playerguid`),
  KEY `Idx_playerguid` (`playerguid`),
  KEY `Idx_ownerguid` (`ownerguid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Guild System';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `petition_sign`
--

LOCK TABLES `petition_sign` WRITE;
/*!40000 ALTER TABLE `petition_sign` DISABLE KEYS */;
/*!40000 ALTER TABLE `petition_sign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pvpstats_battlegrounds`
--

DROP TABLE IF EXISTS `pvpstats_battlegrounds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvpstats_battlegrounds` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `winner_team` tinyint(3) NOT NULL,
  `bracket_id` tinyint(3) unsigned NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pvpstats_battlegrounds`
--

LOCK TABLES `pvpstats_battlegrounds` WRITE;
/*!40000 ALTER TABLE `pvpstats_battlegrounds` DISABLE KEYS */;
/*!40000 ALTER TABLE `pvpstats_battlegrounds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pvpstats_players`
--

DROP TABLE IF EXISTS `pvpstats_players`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pvpstats_players` (
  `battleground_id` bigint(20) unsigned NOT NULL,
  `character_guid` int(10) unsigned NOT NULL,
  `score_killing_blows` mediumint(8) unsigned NOT NULL,
  `score_deaths` mediumint(8) unsigned NOT NULL,
  `score_honorable_kills` mediumint(8) unsigned NOT NULL,
  `score_bonus_honor` mediumint(8) unsigned NOT NULL,
  `score_damage_done` mediumint(8) unsigned NOT NULL,
  `score_healing_done` mediumint(8) unsigned NOT NULL,
  `attr_1` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attr_2` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attr_3` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attr_4` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `attr_5` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`battleground_id`,`character_guid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pvpstats_players`
--

LOCK TABLES `pvpstats_players` WRITE;
/*!40000 ALTER TABLE `pvpstats_players` DISABLE KEYS */;
/*!40000 ALTER TABLE `pvpstats_players` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saved_variables`
--

DROP TABLE IF EXISTS `saved_variables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `saved_variables` (
  `NextArenaPointDistributionTime` bigint(40) unsigned NOT NULL DEFAULT '0',
  `NextDailyQuestResetTime` bigint(40) unsigned NOT NULL DEFAULT '0',
  `NextWeeklyQuestResetTime` bigint(40) unsigned NOT NULL DEFAULT '0',
  `NextMonthlyQuestResetTime` bigint(40) unsigned NOT NULL DEFAULT '0',
  `cleaning_flags` int(11) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='Variable Saves';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saved_variables`
--

LOCK TABLES `saved_variables` WRITE;
/*!40000 ALTER TABLE `saved_variables` DISABLE KEYS */;
INSERT INTO `saved_variables` VALUES (0,1490421600,1490767200,1491026400,0);
/*!40000 ALTER TABLE `saved_variables` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `world`
--

DROP TABLE IF EXISTS `world`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `world` (
  `map` int(11) unsigned NOT NULL DEFAULT '0',
  `data` longtext,
  PRIMARY KEY (`map`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `world`
--

LOCK TABLES `world` WRITE;
/*!40000 ALTER TABLE `world` DISABLE KEYS */;
INSERT INTO `world` VALUES (0,''),(1,''),(530,'');
/*!40000 ALTER TABLE `world` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-24  8:00:00
